import { ReactNode } from "react";

interface AnimatedBackgroundProps {
  children: ReactNode;
  variant?: "gradient" | "image";
  imageUrl?: string;
  className?: string;
}

export function AnimatedBackground({
  children,
  variant = "gradient",
  imageUrl,
  className = "",
}: AnimatedBackgroundProps) {
  return (
    <div className={`relative ${className}`}>
      {variant === "gradient" && (
        <div className="absolute inset-0 bg-gradient-animated">
          {/* Animated particles */}
          <div className="absolute inset-0 overflow-hidden pointer-events-none">
            <div className="animate-float absolute top-1/4 left-1/4 w-20 h-20 rounded-full bg-primary-500/20 backdrop-blur-sm"></div>
            <div className="animate-float absolute top-1/3 right-1/3 w-32 h-32 rounded-full bg-secondary-500/10 backdrop-blur-sm" style={{ animationDelay: "1s" }}></div>
            <div className="animate-float absolute bottom-1/4 right-1/4 w-24 h-24 rounded-full bg-primary-600/15 backdrop-blur-sm" style={{ animationDelay: "2s" }}></div>
            <div className="animate-float absolute bottom-1/3 left-1/3 w-16 h-16 rounded-full bg-secondary-400/10 backdrop-blur-sm" style={{ animationDelay: "3s" }}></div>
          </div>
        </div>
      )}
      
      {variant === "image" && imageUrl && (
        <>
          <div 
            className="absolute inset-0 bg-cover bg-center opacity-10 mix-blend-overlay"
            style={{ backgroundImage: `url('${imageUrl}')` }}
          ></div>
          {/* Animated particles - fewer for image backgrounds */}
          <div className="absolute inset-0 overflow-hidden pointer-events-none">
            <div className="animate-float absolute top-1/3 left-1/4 w-32 h-32 rounded-full bg-primary-500/15 backdrop-blur-sm" style={{ animationDelay: "2s" }}></div>
            <div className="animate-float absolute bottom-1/3 right-1/4 w-40 h-40 rounded-full bg-secondary-500/10 backdrop-blur-sm" style={{ animationDelay: "3s" }}></div>
          </div>
        </>
      )}
      
      {/* Content */}
      <div className="relative z-10">
        {children}
      </div>
    </div>
  );
}
