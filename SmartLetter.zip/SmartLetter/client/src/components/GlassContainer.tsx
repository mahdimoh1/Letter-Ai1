import { cn } from "@/lib/utils";
import { ReactNode } from "react";

interface GlassContainerProps {
  children: ReactNode;
  variant?: "light" | "dark";
  className?: string;
  animateFloat?: boolean;
}

export function GlassContainer({
  children,
  variant = "light",
  className,
  animateFloat = false,
}: GlassContainerProps) {
  return (
    <div
      className={cn(
        variant === "light" ? "glass" : "glass-dark",
        animateFloat && "animate-float",
        className
      )}
    >
      {children}
    </div>
  );
}
