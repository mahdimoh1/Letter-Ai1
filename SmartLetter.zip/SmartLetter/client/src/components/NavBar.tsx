import { ThemeModeToggle } from "./ThemeModeToggle";
import { LanguageToggle } from "./LanguageToggle";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { Logo } from "./ui/logo";
import { useTranslation } from "react-i18next";
import { getRemainingLetterCount } from "@/lib/utils";
import { Badge } from "./ui/badge";

export function NavBar() {
  const { user, logoutMutation } = useAuth();
  const [location, navigate] = useLocation();
  const { t } = useTranslation();

  const handleLogout = () => {
    logoutMutation.mutate(undefined, {
      onSuccess: () => {
        navigate("/");
      }
    });
  };

  return (
    <nav className="fixed top-0 w-full z-50 glass dark:glass-dark">
      <div className="container mx-auto px-4 py-3">
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <a href="/" className="flex items-center">
              <Logo />
            </a>
          </div>
          
          <div className="hidden md:flex items-center space-x-8">
            <a 
              href="/#features" 
              className="text-gray-700 dark:text-gray-300 hover:text-primary-500 dark:hover:text-primary-400 transition-colors"
            >
              {t('common.features')}
            </a>
            <a 
              href="/#how-it-works" 
              className="text-gray-700 dark:text-gray-300 hover:text-primary-500 dark:hover:text-primary-400 transition-colors"
            >
              {t('common.howItWorks')}
            </a>
            <a 
              href="/pricing" 
              className="text-gray-700 dark:text-gray-300 hover:text-primary-500 dark:hover:text-primary-400 transition-colors"
            >
              {t('common.pricing')}
            </a>
            
            {user && (
              <>
                <a 
                  href="/letter" 
                  className="text-gray-700 dark:text-gray-300 hover:text-primary-500 dark:hover:text-primary-400 transition-colors"
                >
                  {t('common.newLetter')}
                  {!user.isPremium && user.monthlyLetterCount < 3 && (
                    <Badge
                      variant="premium"
                      className="ml-2 text-xs"
                    >
                      {getRemainingLetterCount(user.monthlyLetterCount)} left
                    </Badge>
                  )}
                </a>
                <a 
                  href="/my-letters" 
                  className="text-gray-700 dark:text-gray-300 hover:text-primary-500 dark:hover:text-primary-400 transition-colors"
                >
                  {t('common.myLetters')}
                </a>
              </>
            )}
          </div>
          
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <LanguageToggle />
              <ThemeModeToggle />
            </div>
            
            <div className="flex items-center space-x-2">
              {user ? (
                <>
                  {user.isPremium && (
                    <Badge variant="premium" className="mr-2">Premium</Badge>
                  )}
                  <Button 
                    variant="ghost"
                    onClick={handleLogout}
                    className="py-2 px-4 rounded-lg glass hover:bg-white/20 text-primary-700 dark:text-primary-300 font-medium transition-all"
                  >
                    {t('common.logout')}
                  </Button>
                </>
              ) : (
                <>
                  <Button
                    variant="ghost"
                    onClick={() => navigate("/auth")}
                    className="py-2 px-4 rounded-lg glass hover:bg-white/20 text-primary-700 dark:text-primary-300 font-medium transition-all"
                  >
                    {t('common.login')}
                  </Button>
                  <Button
                    onClick={() => navigate("/auth")}
                    className="py-2 px-4 rounded-lg bg-gradient-to-r from-primary-500 to-secondary-500 text-white font-medium hover:shadow-lg hover:shadow-primary-500/20 transition-all"
                  >
                    {t('common.signup')}
                  </Button>
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
}
