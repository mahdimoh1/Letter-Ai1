import { languages } from "@shared/schema";
import { cn } from "@/lib/utils";
import { useTranslation } from "react-i18next";

interface LanguageSelectorProps {
  selectedLanguage: string;
  onChange: (language: string) => void;
}

export function LanguageSelector({
  selectedLanguage,
  onChange
}: LanguageSelectorProps) {
  const { t } = useTranslation();

  return (
    <div className="pt-4">
      <h4 className="text-sm uppercase text-gray-400 font-medium mb-2">
        {t('letter.languageOutput')}
      </h4>
      <div className="flex space-x-3">
        {languages.map(language => (
          <label 
            key={language.id}
            className={cn(
              "glass rounded-lg px-4 py-2 cursor-pointer flex items-center transition-colors hover:bg-white/10",
              selectedLanguage === language.id ? "border-primary-400" : "border-white/10"
            )}
          >
            <input 
              type="radio" 
              name="language" 
              value={language.id} 
              className="hidden"
              checked={selectedLanguage === language.id}
              onChange={() => onChange(language.id)}
            />
            <div className={cn(
              "w-4 h-4 rounded-full border-2 flex items-center justify-center mr-2",
              selectedLanguage === language.id ? "border-primary-400" : "border-white/50"
            )}>
              <div className={cn(
                "w-2 h-2 rounded-full",
                selectedLanguage === language.id ? "bg-primary-400" : "bg-transparent"
              )}></div>
            </div>
            <span>
              {language.id === 'en' ? t('letter.english') : t('letter.persian')}
            </span>
          </label>
        ))}
      </div>
    </div>
  );
}
