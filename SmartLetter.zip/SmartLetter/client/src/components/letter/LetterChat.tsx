import { GlassContainer } from "../GlassContainer";
import { LetterForm } from "./LetterForm";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Bot } from "lucide-react";
import { useTranslation } from "react-i18next";

export interface Message {
  role: "user" | "assistant" | "model";
  content: string;
}

interface LetterChatProps {
  messages: Message[];
  onSendMessage: (content: string) => void;
  placeholderText: string;
  isLoading?: boolean;
}

export function LetterChat({
  messages,
  onSendMessage,
  placeholderText,
  isLoading = false
}: LetterChatProps) {
  const { t } = useTranslation();
  
  return (
    <GlassContainer
      variant="dark"
      className="rounded-xl overflow-hidden flex flex-col"
    >
      <div className="bg-gray-800/50 p-4 border-b border-gray-700">
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 rounded-full bg-gradient-to-r from-primary-500 to-secondary-500 flex items-center justify-center">
            <Bot className="h-5 w-5 text-white" />
          </div>
          <div>
            <h3 className="text-white font-medium">AI Letter Assistant</h3>
            <div className="flex items-center text-xs text-gray-400">
              <span className="inline-block w-2 h-2 bg-green-400 rounded-full mr-1"></span>
              Ready to help
            </div>
          </div>
        </div>
      </div>
      
      <div className="flex-1 p-4 overflow-y-auto h-80 space-y-4">
        {messages.map((message, index) => (
          <div 
            key={index} 
            className={`flex items-start ${
              message.role === 'user' ? 'flex-row-reverse space-x-3 space-x-reverse' : 'space-x-3'
            }`}
          >
            {(message.role === 'assistant' || message.role === 'model') ? (
              <Avatar className="w-8 h-8 bg-gradient-to-r from-primary-500 to-secondary-500">
                <AvatarFallback>AI</AvatarFallback>
                <AvatarImage src="" />
              </Avatar>
            ) : (
              <Avatar className="w-8 h-8 bg-gray-200">
                <AvatarFallback className="text-gray-700">
                  <i className="fas fa-user"></i>
                </AvatarFallback>
              </Avatar>
            )}
            <div className={`rounded-xl p-3 text-sm max-w-xs ${
              message.role === 'user' 
                ? 'bg-primary-600/30' 
                : 'glass'
            }`}>
              <p className="text-gray-200 whitespace-pre-wrap">{message.content}</p>
            </div>
          </div>
        ))}
        
        {messages.length === 0 && (
          <div className="flex items-center justify-center h-full">
            <p className="text-gray-400 text-sm">Start a conversation to get help with your letter</p>
          </div>
        )}
      </div>
      
      <LetterForm 
        placeholderText={placeholderText}
        onSubmit={onSendMessage}
        isLoading={isLoading}
      />
    </GlassContainer>
  );
}
