import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useState } from "react";
import { useTranslation } from "react-i18next";
import { Layers, Loader2, AlertCircle } from "lucide-react";

interface LetterFormProps {
  placeholderText: string;
  onSubmit: (content: string) => void;
  isLoading?: boolean;
  maxLength?: number;
}

export function LetterForm({
  placeholderText,
  onSubmit,
  isLoading = false,
  maxLength = 5000 // Default max length
}: LetterFormProps) {
  const { t } = useTranslation();
  const [content, setContent] = useState('');
  
  const handleSubmit = () => {
    if (content.trim()) {
      onSubmit(content);
    }
  };
  
  const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const newContent = e.target.value;
    // Limit the content to maxLength characters
    if (newContent.length <= maxLength) {
      setContent(newContent);
    }
  };
  
  const charCount = content.length;
  const isNearLimit = charCount > maxLength * 0.9;
  const isAtLimit = charCount === maxLength;
  
  return (
    <div className="p-4 border-t border-gray-700">
      <div className="relative">
        <Textarea
          className="w-full py-3 px-4 pr-10 rounded-lg glass-dark border border-gray-700 focus:border-primary-500 outline-none text-white text-sm min-h-[100px]"
          placeholder={placeholderText}
          value={content}
          onChange={handleChange}
          disabled={isLoading}
          maxLength={maxLength}
        />
        <Button
          className="absolute right-3 bottom-3 px-4 py-2 rounded-lg bg-gradient-to-r from-primary-500 to-secondary-500 text-white text-sm flex items-center"
          onClick={handleSubmit}
          disabled={isLoading || !content.trim()}
        >
          {isLoading ? (
            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
          ) : (
            <Layers className="h-4 w-4 mr-2" />
          )}
          {t('letter.submit')}
        </Button>
      </div>
      <div className="mt-2 flex justify-between items-center">
        <span className="text-xs text-gray-400 flex items-center">
          <i className="fas fa-lock mr-1"></i>
          {t('letter.secureProcessing')}
        </span>
        <div className={`text-xs ${isAtLimit ? 'text-red-400' : isNearLimit ? 'text-yellow-400' : 'text-gray-400'} flex items-center`}>
          {isNearLimit && <AlertCircle className="h-3 w-3 mr-1" />}
          {charCount}/{maxLength} {t('letter.characters')}
        </div>
      </div>
    </div>
  );
}
