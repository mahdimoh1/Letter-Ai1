import { Button } from "@/components/ui/button";
import { useTranslation } from "react-i18next";
import { GlassContainer } from "../GlassContainer";
import { CheckIcon, Edit, Check, Download } from "lucide-react";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

interface LetterResultProps {
  content: string;
  onEdit: () => void;
  onFinalize: (content: string) => void;
}

export function LetterResult({
  content,
  onEdit,
  onFinalize
}: LetterResultProps) {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [editedContent, setEditedContent] = useState(content);
  const [isEditing, setIsEditing] = useState(false);
  
  const handleFinalize = () => {
    onFinalize(editedContent);
    toast({
      title: "Letter finalized",
      description: "Your letter has been saved successfully.",
      duration: 3000,
    });
  };
  
  const handleEditToggle = () => {
    if (isEditing) {
      // Save the edits
      setIsEditing(false);
    } else {
      // Enter edit mode
      setIsEditing(true);
    }
  };
  
  const downloadLetter = () => {
    const element = document.createElement("a");
    const file = new Blob([editedContent], {type: 'text/plain'});
    element.href = URL.createObjectURL(file);
    element.download = "letter.txt";
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };
  
  return (
    <GlassContainer
      variant="dark"
      className="rounded-xl p-6 flex flex-col"
    >
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-xl font-semibold text-white">Final Letter</h3>
        <div className="flex space-x-2">
          <Button
            size="sm"
            variant="outline"
            onClick={handleEditToggle}
            className="flex items-center"
          >
            {isEditing ? (
              <>
                <Check className="h-4 w-4 mr-2" />
                Save Edits
              </>
            ) : (
              <>
                <Edit className="h-4 w-4 mr-2" />
                {t('letter.editRequest')}
              </>
            )}
          </Button>
          <Button
            size="sm"
            variant="default"
            onClick={downloadLetter}
            className="flex items-center"
          >
            <Download className="h-4 w-4 mr-2" />
            Download
          </Button>
        </div>
      </div>
      
      <div className="flex-1 mb-6">
        {isEditing ? (
          <textarea
            className="w-full h-64 p-4 bg-gray-800/50 border border-gray-700 rounded-lg text-gray-100 focus:border-primary-500 outline-none"
            value={editedContent}
            onChange={(e) => setEditedContent(e.target.value)}
          />
        ) : (
          <div className="bg-gray-800/50 border border-gray-700 rounded-lg p-4 h-64 overflow-y-auto text-gray-100 whitespace-pre-wrap">
            {editedContent}
          </div>
        )}
      </div>
      
      <div className="flex justify-center">
        <Button
          onClick={handleFinalize}
          className="bg-gradient-to-r from-primary-500 to-secondary-500 text-white font-medium hover:shadow-lg hover:shadow-primary-500/20 transition-all"
        >
          <CheckIcon className="h-5 w-5 mr-2" />
          {t('letter.finalize')}
        </Button>
      </div>
    </GlassContainer>
  );
}
