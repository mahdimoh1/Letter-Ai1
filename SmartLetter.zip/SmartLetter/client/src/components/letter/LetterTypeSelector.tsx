import { letterTypes } from "@shared/schema";
import { cn } from "@/lib/utils";
import { useTranslation } from "react-i18next";

interface LetterTypeSelectorProps {
  selectedType: string;
  onChange: (type: string) => void;
}

export function LetterTypeSelector({
  selectedType,
  onChange
}: LetterTypeSelectorProps) {
  const { t } = useTranslation();

  return (
    <div className="space-y-4">
      <h3 className="text-xl font-semibold mb-4">{t('letter.chooseLetterType')}</h3>
      
      <div className="space-y-3">
        {letterTypes.map(type => (
          <label 
            key={type.id}
            className={cn(
              "block glass hover:bg-white/10 p-4 rounded-xl cursor-pointer transition-colors",
              selectedType === type.id ? "border-primary-400" : "border-white/10"
            )}
          >
            <input 
              type="radio" 
              name="letter-type" 
              value={type.id} 
              className="hidden"
              checked={selectedType === type.id}
              onChange={() => onChange(type.id)}
            />
            <div className="flex items-center">
              <div className={cn(
                "w-5 h-5 rounded-full border-2 flex items-center justify-center mr-3",
                selectedType === type.id ? "border-primary-400" : "border-white/50"
              )}>
                <div className={cn(
                  "w-3 h-3 rounded-full",
                  selectedType === type.id ? "bg-primary-400" : "bg-transparent"
                )}></div>
              </div>
              <div>
                <span className="font-medium">
                  {type.id === 'reply' ? t('letter.replyToLetter') : t('letter.newLetter')}
                </span>
                <p className="text-sm text-gray-300 mt-1">
                  {type.id === 'reply' ? t('letter.replyDesc') : t('letter.newLetterDesc')}
                </p>
              </div>
            </div>
          </label>
        ))}
      </div>
    </div>
  );
}
