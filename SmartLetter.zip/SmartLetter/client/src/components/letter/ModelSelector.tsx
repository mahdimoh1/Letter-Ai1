import { aiModels } from "@shared/schema";
import { useTranslation } from "react-i18next";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface ModelSelectorProps {
  selectedModel: string;
  onChange: (model: string) => void;
  disabled?: boolean;
  isPremium: boolean;
}

export function ModelSelector({
  selectedModel,
  onChange,
  disabled = false,
  isPremium
}: ModelSelectorProps) {
  const { t } = useTranslation();

  // Filter models based on premium status - non-premium users can only use specific models
  const availableModels = isPremium 
    ? aiModels 
    : aiModels.filter(model => model.id === "gemini-1.5-pro" || model.id === "gemini-pro-vision");

  return (
    <div className="pt-4">
      <h4 className="text-sm uppercase text-gray-400 font-medium mb-2">
        {t('letter.aiModel')}
      </h4>
      <Select
        value={selectedModel}
        onValueChange={onChange}
        disabled={disabled}
      >
        <SelectTrigger className="glass w-full rounded-lg px-4 py-2 bg-transparent border border-gray-600 focus:border-primary-400 outline-none">
          <SelectValue placeholder="Select a model" />
        </SelectTrigger>
        <SelectContent>
          <SelectGroup>
            <SelectLabel>AI Models</SelectLabel>
            {availableModels.map(model => (
              <SelectItem key={model.id} value={model.id}>
                {model.name}
                {model.provider ? ` (${model.provider})` : ''}
                {!isPremium && model.id === "openai/gpt-3.5-turbo" && " - Premium Only"}
              </SelectItem>
            ))}
          </SelectGroup>
        </SelectContent>
      </Select>
      
      {!isPremium && (
        <p className="text-xs text-gray-400 mt-1">
          Upgrade to Premium for access to all AI models
        </p>
      )}
    </div>
  );
}
