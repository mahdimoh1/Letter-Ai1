import { cn } from "@/lib/utils";

interface LogoProps {
  className?: string;
  size?: "sm" | "md" | "lg";
}

export function Logo({ className, size = "md" }: LogoProps) {
  const sizes = {
    sm: "w-8 h-8 text-base",
    md: "w-10 h-10 text-lg",
    lg: "w-12 h-12 text-xl",
  };

  return (
    <div className="flex items-center">
      <div
        className={cn(
          "rounded-full bg-gradient-to-r from-primary-600 to-secondary-500 flex items-center justify-center mr-2 animate-pulse-glow",
          sizes[size],
          className
        )}
      >
        <i className={`fas fa-robot text-white ${sizes[size].split(" ")[2]}`}></i>
      </div>
      <span className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-primary-500 to-secondary-400">
        AI Letter Assistant
      </span>
    </div>
  );
}
