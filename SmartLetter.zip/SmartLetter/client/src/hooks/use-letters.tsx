import { useAuth } from "./use-auth";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Letter, InsertLetter } from "@shared/schema";

export interface Message {
  role: "user" | "assistant" | "model";
  content: string;
}

export function useLetters() {
  const { user } = useAuth();
  const { toast } = useToast();

  // Get all letters
  const {
    data: letters = [],
    isLoading: isLoadingLetters,
    error: lettersError,
  } = useQuery<Letter[]>({
    queryKey: ["/api/letters"],
    enabled: !!user,
  });

  // Create letter mutation
  const createLetterMutation = useMutation({
    mutationFn: async (letter: InsertLetter) => {
      const res = await apiRequest("POST", "/api/letters", letter);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/letters"] });
      queryClient.invalidateQueries({ queryKey: ["/api/user"] }); // refresh user to update letter count
      toast({
        title: "Letter created",
        description: "Your letter has been saved successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Letter creation failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // AI analyze letter mutation
  const analyzeLetterMutation = useMutation({
    mutationFn: async ({ 
      content, 
      type, 
      language, 
      model,
      history = [] 
    }: { 
      content: string;
      type: string;
      language: string;
      model: string;
      history?: Message[];
    }) => {
      const res = await apiRequest("POST", "/api/letters/analyze", {
        content,
        type,
        language,
        model,
        history,
      });
      return await res.json();
    },
    onError: (error: Error) => {
      toast({
        title: "Letter analysis failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // AI generate letter mutation
  const generateLetterMutation = useMutation({
    mutationFn: async ({ 
      content, 
      type, 
      language, 
      model,
      history = [] 
    }: { 
      content: string;
      type: string;
      language: string;
      model: string;
      history?: Message[];
    }) => {
      const res = await apiRequest("POST", "/api/letters/generate", {
        content,
        type,
        language,
        model,
        history,
      });
      return await res.json();
    },
    onError: (error: Error) => {
      toast({
        title: "Letter generation failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  return {
    letters,
    isLoadingLetters,
    lettersError,
    createLetterMutation,
    analyzeLetterMutation,
    generateLetterMutation,
  };
}
