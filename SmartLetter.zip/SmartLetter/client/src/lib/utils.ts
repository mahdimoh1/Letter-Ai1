import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Add i18next type to Window
declare global {
  interface Window {
    i18next?: {
      language: string;
    };
  }
}

export function formatDate(date: Date, locale?: string): string {
  // Use the provided locale or get from i18next if available
  const currentLocale = locale || 
    (typeof window !== 'undefined' && 
     window.i18next?.language === 'fa' ? 'fa-IR' : 'en-US');
  
  return new Intl.DateTimeFormat(currentLocale, {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  }).format(date);
}

export function truncateText(text: string, maxLength: number): string {
  if (text.length <= maxLength) return text;
  return text.slice(0, maxLength) + '...';
}

export function getGradientClass() {
  return 'bg-clip-text text-transparent bg-gradient-to-r from-primary-600 to-secondary-500';
}

export function debounce<T extends (...args: any[]) => any>(
  fn: T,
  ms: number
): (...args: Parameters<T>) => void {
  let timeout: NodeJS.Timeout;
  
  return (...args: Parameters<T>) => {
    clearTimeout(timeout);
    timeout = setTimeout(() => fn(...args), ms);
  };
}

// Utility to get remaining letters count for free users
export function getRemainingLetterCount(monthlyLetterCount: number) {
  const maxFreeLetters = 3;
  return Math.max(0, maxFreeLetters - monthlyLetterCount);
}

// Utility to validate email
export function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

// Utility to detect language direction
export function getLanguageDirection(language: string): 'ltr' | 'rtl' {
  return language === 'fa' ? 'rtl' : 'ltr';
}
