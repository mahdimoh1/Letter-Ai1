import { useState, useEffect } from "react";
import { NavBar } from "@/components/NavBar";
import { AnimatedBackground } from "@/components/AnimatedBackground";
import { GlassContainer } from "@/components/GlassContainer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Prompt, languages, insertPromptSchema } from "@shared/schema";
import { Pencil, Trash2, Save, Plus, Loader2, CheckCircle } from "lucide-react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";

// Form validation schema
const promptFormSchema = z.object({
  type: z.string().min(1, "Type is required"),
  language: z.string().min(1, "Language is required"),
  content: z.string().min(10, "Content must be at least 10 characters"),
  isDefault: z.boolean().optional(),
});

type PromptFormValues = z.infer<typeof promptFormSchema>;

export default function AdminPage() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [editingPrompt, setEditingPrompt] = useState<Prompt | null>(null);
  const [isCreating, setIsCreating] = useState(false);
  
  // Fetch prompts
  const { 
    data: prompts = [], 
    isLoading,
    error,
    refetch 
  } = useQuery<Prompt[]>({
    queryKey: ["/api/prompts"],
  });
  
  // Form for editing/creating prompts
  const form = useForm<PromptFormValues>({
    resolver: zodResolver(promptFormSchema),
    defaultValues: {
      type: "new",
      language: "en",
      content: "",
      isDefault: false,
    },
  });
  
  // Update form when editing prompt changes
  useEffect(() => {
    if (editingPrompt) {
      form.reset({
        type: editingPrompt.type,
        language: editingPrompt.language,
        content: editingPrompt.content,
        isDefault: editingPrompt.isDefault,
      });
    } else if (isCreating) {
      form.reset({
        type: "new",
        language: "en",
        content: "",
        isDefault: false,
      });
    }
  }, [editingPrompt, isCreating, form]);
  
  // Create prompt mutation
  const createPromptMutation = useMutation({
    mutationFn: async (prompt: PromptFormValues) => {
      const res = await apiRequest("POST", "/api/prompts", prompt);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/prompts"] });
      toast({
        title: "Prompt created",
        description: "The prompt has been created successfully.",
      });
      setIsCreating(false);
      form.reset();
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to create prompt",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Update prompt mutation
  const updatePromptMutation = useMutation({
    mutationFn: async ({ id, prompt }: { id: number, prompt: PromptFormValues }) => {
      const res = await apiRequest("PUT", `/api/prompts/${id}`, prompt);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/prompts"] });
      toast({
        title: "Prompt updated",
        description: "The prompt has been updated successfully.",
      });
      setEditingPrompt(null);
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to update prompt",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Delete prompt mutation
  const deletePromptMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/prompts/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/prompts"] });
      toast({
        title: "Prompt deleted",
        description: "The prompt has been deleted successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to delete prompt",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Handle form submission
  const onSubmit = (data: PromptFormValues) => {
    if (editingPrompt) {
      updatePromptMutation.mutate({ id: editingPrompt.id, prompt: data });
    } else {
      createPromptMutation.mutate(data);
    }
  };
  
  // Handle delete button click
  const handleDelete = (id: number) => {
    if (confirm("Are you sure you want to delete this prompt?")) {
      deletePromptMutation.mutate(id);
    }
  };
  
  return (
    <div className="min-h-screen flex flex-col">
      <NavBar />
      
      <AnimatedBackground className="flex-1 pt-32 pb-20">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="flex justify-between items-center mb-8">
              <h1 className="text-3xl font-bold text-white">Admin Dashboard</h1>
              
              <div className="flex items-center space-x-4">
                {!isCreating && !editingPrompt && (
                  <Button 
                    onClick={() => setIsCreating(true)}
                    className="bg-gradient-to-r from-primary-500 to-secondary-500"
                  >
                    <Plus className="mr-2 h-4 w-4" />
                    Add New Prompt
                  </Button>
                )}
              </div>
            </div>
            
            {/* Prompt Editor */}
            {(isCreating || editingPrompt) && (
              <GlassContainer variant="dark" className="mb-8 p-6 rounded-xl">
                <h2 className="text-xl font-semibold text-white mb-4">
                  {editingPrompt ? "Edit Prompt" : "Create New Prompt"}
                </h2>
                
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <Label htmlFor="prompt-type">Prompt Type</Label>
                      <Select
                        onValueChange={(value) => form.setValue("type", value)}
                        defaultValue={form.getValues("type")}
                      >
                        <SelectTrigger className="glass border border-gray-600">
                          <SelectValue placeholder="Select type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="new">New Letter</SelectItem>
                          <SelectItem value="reply">Reply to Letter</SelectItem>
                        </SelectContent>
                      </Select>
                      {form.formState.errors.type && (
                        <p className="text-red-500 text-sm mt-1">
                          {form.formState.errors.type.message}
                        </p>
                      )}
                    </div>
                    
                    <div>
                      <Label htmlFor="prompt-language">Language</Label>
                      <Select
                        onValueChange={(value) => form.setValue("language", value)}
                        defaultValue={form.getValues("language")}
                      >
                        <SelectTrigger className="glass border border-gray-600">
                          <SelectValue placeholder="Select language" />
                        </SelectTrigger>
                        <SelectContent>
                          {languages.map(lang => (
                            <SelectItem key={lang.id} value={lang.id}>
                              {lang.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      {form.formState.errors.language && (
                        <p className="text-red-500 text-sm mt-1">
                          {form.formState.errors.language.message}
                        </p>
                      )}
                    </div>
                  </div>
                  
                  <div>
                    <Label htmlFor="prompt-content">Prompt Content</Label>
                    <Textarea
                      id="prompt-content"
                      className="glass-dark border border-gray-600 min-h-[200px]"
                      placeholder="Enter the prompt content..."
                      {...form.register("content")}
                    />
                    {form.formState.errors.content && (
                      <p className="text-red-500 text-sm mt-1">
                        {form.formState.errors.content.message}
                      </p>
                    )}
                  </div>
                  
                  <div className="flex items-center">
                    <input
                      type="checkbox"
                      id="is-default"
                      className="mr-2"
                      {...form.register("isDefault")}
                    />
                    <Label htmlFor="is-default">Set as default prompt for this type and language</Label>
                  </div>
                  
                  <div className="flex justify-end space-x-3">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => {
                        setEditingPrompt(null);
                        setIsCreating(false);
                      }}
                    >
                      Cancel
                    </Button>
                    <Button 
                      type="submit"
                      className="bg-gradient-to-r from-primary-500 to-secondary-500"
                      disabled={createPromptMutation.isPending || updatePromptMutation.isPending}
                    >
                      {(createPromptMutation.isPending || updatePromptMutation.isPending) && (
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      )}
                      <Save className="mr-2 h-4 w-4" />
                      Save Prompt
                    </Button>
                  </div>
                </form>
              </GlassContainer>
            )}
            
            {/* Prompts Table */}
            <GlassContainer variant="dark" className="rounded-xl p-6">
              <h2 className="text-xl font-semibold text-white mb-4">
                Prompts
              </h2>
              
              {isLoading ? (
                <div className="flex justify-center items-center py-8">
                  <Loader2 className="h-8 w-8 animate-spin text-primary-500" />
                </div>
              ) : error ? (
                <div className="bg-red-500/20 text-white p-4 rounded-lg">
                  <p>Error loading prompts. Please try again.</p>
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Type</TableHead>
                      <TableHead>Language</TableHead>
                      <TableHead>Content</TableHead>
                      <TableHead>Default</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {prompts.map((prompt) => (
                      <TableRow key={prompt.id}>
                        <TableCell className="font-medium">
                          {prompt.type === "new" ? "New Letter" : "Reply to Letter"}
                        </TableCell>
                        <TableCell>
                          {prompt.language === "en" ? "English" : "Persian"}
                        </TableCell>
                        <TableCell className="max-w-xs truncate">
                          {prompt.content.substring(0, 80)}...
                        </TableCell>
                        <TableCell>
                          {prompt.isDefault ? (
                            <CheckCircle className="h-5 w-5 text-green-500" />
                          ) : null}
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end space-x-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => setEditingPrompt(prompt)}
                            >
                              <Pencil className="h-4 w-4" />
                            </Button>
                            <Button
                              size="sm"
                              variant="destructive"
                              onClick={() => handleDelete(prompt.id)}
                              disabled={deletePromptMutation.isPending}
                            >
                              {deletePromptMutation.isPending ? (
                                <Loader2 className="h-4 w-4 animate-spin" />
                              ) : (
                                <Trash2 className="h-4 w-4" />
                              )}
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                    
                    {prompts.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center py-8 text-gray-400">
                          No prompts found. Click "Add New Prompt" to create one.
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              )}
            </GlassContainer>
          </div>
        </div>
      </AnimatedBackground>
    </div>
  );
}
