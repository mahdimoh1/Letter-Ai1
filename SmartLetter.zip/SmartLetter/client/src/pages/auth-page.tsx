import { NavBar } from "@/components/NavBar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { GlassContainer } from "@/components/GlassContainer";
import { AnimatedBackground } from "@/components/AnimatedBackground";
import { Checkbox } from "@/components/ui/checkbox";
import { useAuth } from "@/hooks/use-auth";
import { useLocation, useRoute } from "wouter";
import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useTranslation } from "react-i18next";
import { Loader2 } from "lucide-react";

// Validation schemas
const loginSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  rememberMe: z.boolean().optional(),
});

const registerSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  confirmPassword: z.string().min(6, "Password must be at least 6 characters"),
  acceptTerms: z.boolean().refine(val => val === true, {
    message: "You must accept the terms and conditions",
  }),
}).refine(data => data.password === data.confirmPassword, {
  message: "Passwords do not match",
  path: ["confirmPassword"],
});

type LoginFormValues = z.infer<typeof loginSchema>;
type RegisterFormValues = z.infer<typeof registerSchema>;

export default function AuthPage() {
  const { t } = useTranslation();
  const { user, loginMutation, registerMutation } = useAuth();
  const [isLoginView, setIsLoginView] = useState(true);
  const [_, navigate] = useLocation();
  
  // Check if user is already logged in
  useEffect(() => {
    if (user) {
      navigate("/");
    }
  }, [user, navigate]);
  
  // Login form
  const loginForm = useForm<LoginFormValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: "",
      password: "",
      rememberMe: false,
    },
  });
  
  // Register form
  const registerForm = useForm<RegisterFormValues>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      username: "",
      password: "",
      confirmPassword: "",
      acceptTerms: false,
    },
  });
  
  const onLoginSubmit = (data: LoginFormValues) => {
    loginMutation.mutate({
      username: data.username,
      password: data.password,
    }, {
      onSuccess: () => {
        navigate("/");
      }
    });
  };
  
  const onRegisterSubmit = (data: RegisterFormValues) => {
    const { confirmPassword, acceptTerms, ...credentials } = data;
    registerMutation.mutate(credentials as any, {
      onSuccess: () => {
        navigate("/");
      }
    });
  };
  
  const toggleView = () => {
    setIsLoginView(!isLoginView);
  };
  
  // If user is already logged in, redirect to home
  if (user) {
    return <div className="flex justify-center items-center min-h-screen">
      <Loader2 className="h-8 w-8 animate-spin text-primary-500" />
    </div>;
  }
  
  return (
    <div className="min-h-screen">
      <NavBar />
      
      <AnimatedBackground className="min-h-screen pt-32 pb-20 flex items-center justify-center">
        <div className="container mx-auto px-4 relative z-10">
          <div className="flex flex-col md:flex-row gap-8 items-center max-w-6xl mx-auto">
            {/* Left side - Auth form */}
            <div className="md:w-1/2 w-full">
              <GlassContainer
                variant="dark"
                className="rounded-2xl p-8 w-full max-w-md mx-auto"
              >
                <div className="text-center mb-6">
                  <div className="w-16 h-16 rounded-full bg-gradient-to-r from-primary-500 to-secondary-500 flex items-center justify-center mx-auto mb-4">
                    <i className="fas fa-user text-white text-xl"></i>
                  </div>
                  <h3 className="text-2xl font-bold text-white">
                    {isLoginView ? t('common.login') : t('common.signup')}
                  </h3>
                </div>
                
                {isLoginView ? (
                  // Login Form
                  <form onSubmit={loginForm.handleSubmit(onLoginSubmit)} className="space-y-4">
                    <div>
                      <Label htmlFor="login-username" className="block text-gray-300 mb-2 text-sm">
                        Username
                      </Label>
                      <Input
                        id="login-username"
                        className="w-full py-3 px-4 rounded-lg glass-dark border border-gray-700 focus:border-primary-500 outline-none text-white"
                        placeholder="johndoe"
                        {...loginForm.register("username")}
                        autoComplete="username"
                      />
                      {loginForm.formState.errors.username && (
                        <p className="text-red-500 text-sm mt-1">
                          {loginForm.formState.errors.username.message}
                        </p>
                      )}
                    </div>
                    
                    <div>
                      <Label htmlFor="login-password" className="block text-gray-300 mb-2 text-sm">
                        Password
                      </Label>
                      <Input
                        id="login-password"
                        type="password"
                        className="w-full py-3 px-4 rounded-lg glass-dark border border-gray-700 focus:border-primary-500 outline-none text-white"
                        placeholder={t('common.passwordPlaceholder')}
                        {...loginForm.register("password")}
                        autoComplete="current-password"
                      />
                      {loginForm.formState.errors.password && (
                        <p className="text-red-500 text-sm mt-1">
                          {loginForm.formState.errors.password.message}
                        </p>
                      )}
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <Checkbox
                          id="remember-me"
                          {...loginForm.register("rememberMe")}
                          className="mr-2"
                          defaultChecked={false}
                          onCheckedChange={(checked) => {
                            loginForm.setValue("rememberMe", checked as boolean, { shouldValidate: true });
                          }}
                        />
                        <Label htmlFor="remember-me" className="text-sm text-gray-300">
                          {t('common.rememberMe')}
                        </Label>
                      </div>
                      <a href="#" className="text-sm text-primary-400 hover:text-primary-300">
                        {t('common.forgotPassword')}
                      </a>
                    </div>
                    
                    <Button
                      type="submit"
                      className="w-full py-3 px-6 rounded-lg bg-gradient-to-r from-primary-500 to-secondary-500 text-white font-medium hover:shadow-lg hover:shadow-primary-500/20 transition-all"
                      disabled={loginMutation.isPending}
                    >
                      {loginMutation.isPending ? (
                        <Loader2 className="h-5 w-5 animate-spin mr-2" />
                      ) : null}
                      {t('common.login')}
                    </Button>
                    
                    <div className="relative flex items-center justify-center mt-4">
                      <div className="border-t border-gray-700 absolute w-full"></div>
                      <span className="bg-gray-900 px-4 relative z-10 text-gray-400 text-sm">
                        {t('common.orContinueWith')}
                      </span>
                    </div>
                    
                    <Button
                      type="button"
                      variant="outline"
                      className="w-full py-3 px-6 rounded-lg border border-gray-700 text-white font-medium hover:bg-gray-800 transition-all flex items-center justify-center"
                    >
                      <i className="fab fa-google mr-2 text-red-500"></i>
                      {t('common.continueWithGoogle')}
                    </Button>
                    
                    <div className="text-center mt-4 text-sm text-gray-400">
                      <span>{t('common.dontHaveAccount')}</span>
                      <button 
                        type="button"
                        onClick={toggleView} 
                        className="text-primary-400 hover:text-primary-300 ml-1"
                      >
                        {t('common.signup')}
                      </button>
                    </div>
                  </form>
                ) : (
                  // Register Form
                  <form onSubmit={registerForm.handleSubmit(onRegisterSubmit)} className="space-y-4">
                    <div>
                      <Label htmlFor="register-username" className="block text-gray-300 mb-2 text-sm">
                        Username
                      </Label>
                      <Input
                        id="register-username"
                        className="w-full py-3 px-4 rounded-lg glass-dark border border-gray-700 focus:border-primary-500 outline-none text-white"
                        placeholder="johndoe"
                        {...registerForm.register("username")}
                        autoComplete="username"
                      />
                      {registerForm.formState.errors.username && (
                        <p className="text-red-500 text-sm mt-1">
                          {registerForm.formState.errors.username.message}
                        </p>
                      )}
                    </div>
                    
                    <div>
                      <Label htmlFor="register-password" className="block text-gray-300 mb-2 text-sm">
                        Password
                      </Label>
                      <Input
                        id="register-password"
                        type="password"
                        className="w-full py-3 px-4 rounded-lg glass-dark border border-gray-700 focus:border-primary-500 outline-none text-white"
                        placeholder={t('common.passwordPlaceholder')}
                        {...registerForm.register("password")}
                        autoComplete="new-password"
                      />
                      {registerForm.formState.errors.password && (
                        <p className="text-red-500 text-sm mt-1">
                          {registerForm.formState.errors.password.message}
                        </p>
                      )}
                    </div>
                    
                    <div>
                      <Label htmlFor="register-confirm-password" className="block text-gray-300 mb-2 text-sm">
                        Confirm Password
                      </Label>
                      <Input
                        id="register-confirm-password"
                        type="password"
                        className="w-full py-3 px-4 rounded-lg glass-dark border border-gray-700 focus:border-primary-500 outline-none text-white"
                        placeholder={t('common.passwordPlaceholder')}
                        {...registerForm.register("confirmPassword")}
                        autoComplete="new-password"
                      />
                      {registerForm.formState.errors.confirmPassword && (
                        <p className="text-red-500 text-sm mt-1">
                          {registerForm.formState.errors.confirmPassword.message}
                        </p>
                      )}
                    </div>
                    
                    <div className="flex items-center">
                      <Checkbox
                        id="accept-terms"
                        {...registerForm.register("acceptTerms", { required: true })}
                        className="mr-2"
                        defaultChecked={false}
                        onCheckedChange={(checked) => {
                          registerForm.setValue("acceptTerms", checked as boolean, { shouldValidate: true });
                        }}
                      />
                      <Label htmlFor="accept-terms" className="text-sm text-gray-300">
                        {t('common.agreeToTerms')}
                      </Label>
                    </div>
                    {registerForm.formState.errors.acceptTerms && (
                      <p className="text-red-500 text-sm">
                        {registerForm.formState.errors.acceptTerms.message}
                      </p>
                    )}
                    
                    <Button
                      type="submit"
                      className="w-full py-3 px-6 rounded-lg bg-gradient-to-r from-primary-500 to-secondary-500 text-white font-medium hover:shadow-lg hover:shadow-primary-500/20 transition-all"
                      disabled={registerMutation.isPending}
                    >
                      {registerMutation.isPending ? (
                        <Loader2 className="h-5 w-5 animate-spin mr-2" />
                      ) : null}
                      {t('common.signup')}
                    </Button>
                    
                    <div className="text-center mt-4 text-sm text-gray-400">
                      <span>{t('common.alreadyHaveAccount')}</span>
                      <button 
                        type="button"
                        onClick={toggleView} 
                        className="text-primary-400 hover:text-primary-300 ml-1"
                      >
                        {t('common.login')}
                      </button>
                    </div>
                  </form>
                )}
              </GlassContainer>
            </div>
            
            {/* Right side - Hero info */}
            <div className="md:w-1/2 text-center md:text-left">
              <h2 className="text-3xl md:text-4xl font-bold mb-6 text-white">
                <span className="block">Craft Perfect Letters</span>
                <span className="bg-clip-text text-transparent bg-gradient-to-r from-secondary-300 to-primary-300">
                  with AI Assistance
                </span>
              </h2>
              
              <div className="space-y-6 text-gray-300">
                <p className="text-lg">
                  AI Letter Assistant helps you create professional-quality letters and responses effortlessly.
                </p>
                
                <ul className="space-y-2">
                  <li className="flex items-center">
                    <div className="w-6 h-6 rounded-full bg-gradient-to-r from-primary-500 to-secondary-500 flex items-center justify-center mr-3">
                      <i className="fas fa-check text-white text-xs"></i>
                    </div>
                    <span>Intelligent AI responses based on your input</span>
                  </li>
                  <li className="flex items-center">
                    <div className="w-6 h-6 rounded-full bg-gradient-to-r from-primary-500 to-secondary-500 flex items-center justify-center mr-3">
                      <i className="fas fa-check text-white text-xs"></i>
                    </div>
                    <span>Support for both English and Persian languages</span>
                  </li>
                  <li className="flex items-center">
                    <div className="w-6 h-6 rounded-full bg-gradient-to-r from-primary-500 to-secondary-500 flex items-center justify-center mr-3">
                      <i className="fas fa-check text-white text-xs"></i>
                    </div>
                    <span>Create new letters or respond to received ones</span>
                  </li>
                  <li className="flex items-center">
                    <div className="w-6 h-6 rounded-full bg-gradient-to-r from-primary-500 to-secondary-500 flex items-center justify-center mr-3">
                      <i className="fas fa-check text-white text-xs"></i>
                    </div>
                    <span>Start with the free tier and upgrade when needed</span>
                  </li>
                </ul>
                
                <div className="pt-6">
                  <GlassContainer className="rounded-lg p-4 inline-block">
                    <div className="flex items-center">
                      <div className="w-12 h-12 rounded-full bg-gradient-to-r from-primary-500 to-secondary-500 flex items-center justify-center mr-4">
                        <i className="fas fa-stars text-white"></i>
                      </div>
                      <div className="text-left">
                        <p className="text-white font-medium">Join our community</p>
                        <p className="text-gray-400 text-sm">Over 5,000 satisfied users</p>
                      </div>
                    </div>
                  </GlassContainer>
                </div>
              </div>
            </div>
          </div>
        </div>
      </AnimatedBackground>
    </div>
  );
}
