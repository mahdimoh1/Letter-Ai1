import { NavBar } from "@/components/NavBar";
import { Button } from "@/components/ui/button";
import { AnimatedBackground } from "@/components/AnimatedBackground";
import { GlassContainer } from "@/components/GlassContainer";
import { useTranslation } from "react-i18next";
import { getGradientClass } from "@/lib/utils";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { 
  MessageSquare, 
  Reply, 
  PenTool, 
  Brain, 
  Languages, 
  Edit, 
  Shield, 
  ChevronRight 
} from "lucide-react";

export default function HomePage() {
  const { t } = useTranslation();
  const [_, navigate] = useLocation();
  const { user } = useAuth();
  
  const gradientTextClass = getGradientClass();
  
  return (
    <div className="min-h-screen flex flex-col">
      <NavBar />
      
      {/* Hero Section */}
      <AnimatedBackground className="pt-32 pb-20 relative overflow-hidden">
        <div className="container mx-auto px-4 relative z-10">
          <div className="flex flex-col lg:flex-row items-center justify-between">
            <div className="lg:w-1/2 mb-10 lg:mb-0 text-center lg:text-left">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 text-white leading-tight">
                <span className="block">{t('home.heroTitle').split(" with AI")[0]}</span>
                <span className="bg-clip-text text-transparent bg-gradient-to-r from-secondary-300 to-primary-300">
                  with AI
                </span>
              </h1>
              
              <p className="text-lg md:text-xl text-gray-200/90 mb-8 max-w-xl mx-auto lg:mx-0">
                {t('home.heroSubtitle')}
              </p>
              
              <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start space-y-4 sm:space-y-0 sm:space-x-4">
                <Button
                  className="w-full sm:w-auto py-6 px-6 rounded-lg bg-gradient-to-r from-primary-500 to-secondary-500 text-white font-medium hover:shadow-lg hover:shadow-primary-500/20 transition-all text-center"
                  onClick={() => navigate(user ? "/letter" : "/auth")}
                >
                  {t('common.tryItNow')}
                </Button>
                <Button
                  variant="outline"
                  className="w-full sm:w-auto py-6 px-6 rounded-lg glass text-primary-200 font-medium hover:bg-white/10 transition-all flex items-center justify-center"
                  onClick={() => {
                    const element = document.getElementById('how-it-works');
                    element?.scrollIntoView({ behavior: 'smooth' });
                  }}
                >
                  {t('common.learnMore')}
                  <ChevronRight className="ml-2 h-4 w-4" />
                </Button>
              </div>
              
              <div className="mt-8 flex items-center justify-center lg:justify-start space-x-2">
                <div className="flex -space-x-2">
                  <img src="https://randomuser.me/api/portraits/women/17.jpg" className="w-8 h-8 rounded-full border-2 border-white" alt="User avatar" />
                  <img src="https://randomuser.me/api/portraits/men/32.jpg" className="w-8 h-8 rounded-full border-2 border-white" alt="User avatar" />
                  <img src="https://randomuser.me/api/portraits/women/44.jpg" className="w-8 h-8 rounded-full border-2 border-white" alt="User avatar" />
                </div>
                <span className="text-sm text-gray-300">{t('common.joinUsers')}</span>
              </div>
            </div>
            
            <div className="lg:w-1/2 relative">
              <GlassContainer 
                variant="dark" 
                className="rounded-2xl p-6 max-w-md mx-auto" 
                animateFloat
              >
                <div className="flex items-center space-x-4 mb-6">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-r from-primary-500 to-secondary-500 flex items-center justify-center">
                    <MessageSquare className="h-5 w-5 text-white" />
                  </div>
                  <div>
                    <h3 className="text-white font-medium">AI Letter Assistant</h3>
                    <div className="text-xs text-gray-300 flex items-center">
                      <span className="inline-block w-2 h-2 bg-green-400 rounded-full mr-1"></span>
                      Active now
                    </div>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div className="flex items-start space-x-3">
                    <div className="w-8 h-8 rounded-full bg-gradient-to-r from-primary-500 to-secondary-500 flex items-center justify-center text-xs text-white">
                      AI
                    </div>
                    <div className="glass rounded-xl p-3 text-sm max-w-xs">
                      <p className="text-gray-200">How would you like me to help with your letter today?</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start flex-row-reverse space-x-3 space-x-reverse">
                    <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center text-xs text-gray-700">
                      <i className="fas fa-user"></i>
                    </div>
                    <div className="bg-primary-600/30 rounded-xl p-3 text-sm max-w-xs">
                      <p className="text-gray-200">I need to respond to a job offer I received yesterday.</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-3">
                    <div className="w-8 h-8 rounded-full bg-gradient-to-r from-primary-500 to-secondary-500 flex items-center justify-center text-xs text-white">
                      AI
                    </div>
                    <div className="glass rounded-xl p-3 text-sm max-w-xs">
                      <p className="text-gray-200">Great! Are you planning to accept the offer, negotiate terms, or decline?</p>
                    </div>
                  </div>
                </div>
                
                <div className="mt-4 relative">
                  <input 
                    type="text" 
                    className="w-full py-3 px-4 pr-10 rounded-lg glass-dark border border-gray-700 focus:border-primary-500 outline-none text-white text-sm" 
                    placeholder="Type your message..."
                  />
                  <button className="absolute right-3 top-1/2 transform -translate-y-1/2 w-8 h-8 rounded-full bg-gradient-to-r from-primary-500 to-secondary-500 flex items-center justify-center text-white">
                    <i className="fas fa-paper-plane text-xs"></i>
                  </button>
                </div>
              </GlassContainer>
              
              {/* Decoration Elements */}
              <div className="absolute -bottom-10 -right-10 w-20 h-20 rounded-full bg-primary-500 filter blur-xl opacity-30"></div>
              <div className="absolute -top-5 -left-5 w-16 h-16 rounded-full bg-secondary-500 filter blur-xl opacity-20"></div>
            </div>
          </div>
        </div>
      </AnimatedBackground>

      {/* Features Section */}
      <section id="features" className="py-20 bg-gray-50 dark:bg-gray-900 relative">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className={`text-3xl md:text-4xl font-bold mb-4 ${gradientTextClass} inline-block`}>
              {t('home.featuresTitle')}
            </h2>
            <p className="text-lg text-gray-600 dark:text-gray-400 max-w-3xl mx-auto">
              {t('home.featuresSubtitle')}
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Feature 1 */}
            <GlassContainer 
              className="rounded-xl p-6 hover:shadow-lg transition-all duration-300 group"
            >
              <div className="w-14 h-14 rounded-lg bg-gradient-to-r from-primary-500 to-primary-600 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <Reply className="text-white h-6 w-6" />
              </div>
              <h3 className="text-xl font-semibold mb-3 text-gray-800 dark:text-white">
                {t('features.replyTitle')}
              </h3>
              <p className="text-gray-600 dark:text-gray-300">
                {t('features.replyDesc')}
              </p>
            </GlassContainer>
            
            {/* Feature 2 */}
            <GlassContainer 
              className="rounded-xl p-6 hover:shadow-lg transition-all duration-300 group"
            >
              <div className="w-14 h-14 rounded-lg bg-gradient-to-r from-secondary-500 to-secondary-600 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <PenTool className="text-white h-6 w-6" />
              </div>
              <h3 className="text-xl font-semibold mb-3 text-gray-800 dark:text-white">
                {t('features.newLetterTitle')}
              </h3>
              <p className="text-gray-600 dark:text-gray-300">
                {t('features.newLetterDesc')}
              </p>
            </GlassContainer>
            
            {/* Feature 3 */}
            <GlassContainer 
              className="rounded-xl p-6 hover:shadow-lg transition-all duration-300 group"
            >
              <div className="w-14 h-14 rounded-lg bg-gradient-to-r from-primary-500 to-secondary-500 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <Brain className="text-white h-6 w-6" />
              </div>
              <h3 className="text-xl font-semibold mb-3 text-gray-800 dark:text-white">
                {t('features.aiClarificationTitle')}
              </h3>
              <p className="text-gray-600 dark:text-gray-300">
                {t('features.aiClarificationDesc')}
              </p>
            </GlassContainer>
            
            {/* Feature 4 */}
            <GlassContainer 
              className="rounded-xl p-6 hover:shadow-lg transition-all duration-300 group"
            >
              <div className="w-14 h-14 rounded-lg bg-gradient-to-r from-primary-600 to-primary-700 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <Languages className="text-white h-6 w-6" />
              </div>
              <h3 className="text-xl font-semibold mb-3 text-gray-800 dark:text-white">
                {t('features.languageSupportTitle')}
              </h3>
              <p className="text-gray-600 dark:text-gray-300">
                {t('features.languageSupportDesc')}
              </p>
            </GlassContainer>
            
            {/* Feature 5 */}
            <GlassContainer 
              className="rounded-xl p-6 hover:shadow-lg transition-all duration-300 group"
            >
              <div className="w-14 h-14 rounded-lg bg-gradient-to-r from-secondary-600 to-secondary-700 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <Edit className="text-white h-6 w-6" />
              </div>
              <h3 className="text-xl font-semibold mb-3 text-gray-800 dark:text-white">
                {t('features.revisionsTitle')}
              </h3>
              <p className="text-gray-600 dark:text-gray-300">
                {t('features.revisionsDesc')}
              </p>
            </GlassContainer>
            
            {/* Feature 6 */}
            <GlassContainer 
              className="rounded-xl p-6 hover:shadow-lg transition-all duration-300 group"
            >
              <div className="w-14 h-14 rounded-lg bg-gradient-to-r from-primary-500 to-secondary-600 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <Shield className="text-white h-6 w-6" />
              </div>
              <h3 className="text-xl font-semibold mb-3 text-gray-800 dark:text-white">
                {t('features.aiModelsTitle')}
              </h3>
              <p className="text-gray-600 dark:text-gray-300">
                {t('features.aiModelsDesc')}
              </p>
            </GlassContainer>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section id="how-it-works" className="py-20 bg-gray-100 dark:bg-gray-800 relative overflow-hidden">
        <div className="absolute inset-0 bg-cover bg-center opacity-5"></div>
        
        <div className="container mx-auto px-4 relative z-10">
          <div className="text-center mb-16">
            <h2 className={`text-3xl md:text-4xl font-bold mb-4 ${gradientTextClass} inline-block`}>
              {t('home.howItWorksTitle')}
            </h2>
            <p className="text-lg text-gray-600 dark:text-gray-400 max-w-3xl mx-auto">
              {t('home.howItWorksSubtitle')}
            </p>
          </div>
          
          <div className="relative">
            {/* Connection line */}
            <div className="absolute left-1/2 top-0 bottom-0 w-1 bg-gradient-to-b from-primary-500 to-secondary-500 hidden md:block transform -translate-x-1/2"></div>
            
            <div className="space-y-24 relative">
              {/* Step 1 */}
              <div className="flex flex-col md:flex-row items-center">
                <div className="md:w-1/2 md:pr-12 mb-8 md:mb-0 text-center md:text-right">
                  <GlassContainer className="rounded-xl p-6 inline-block">
                    <h3 className="text-2xl font-bold mb-4 text-gray-800 dark:text-white">{t('home.step1Title')}</h3>
                    <p className="text-gray-600 dark:text-gray-300">{t('home.step1Desc')}</p>
                  </GlassContainer>
                </div>
                
                <div className="md:w-8 md:h-8 bg-gradient-to-r from-primary-500 to-secondary-500 rounded-full z-10 flex items-center justify-center text-white font-bold relative">
                  <span>1</span>
                  <div className="absolute w-16 h-16 rounded-full border-2 border-primary-500/30 animate-pulse-glow"></div>
                </div>
                
                <div className="md:w-1/2 md:pl-12">
                  <img src="https://images.unsplash.com/photo-1599658880436-c61792e70672" alt="Select letter type" className="rounded-xl shadow-lg max-w-sm mx-auto" />
                </div>
              </div>
              
              {/* Step 2 */}
              <div className="flex flex-col md:flex-row-reverse items-center">
                <div className="md:w-1/2 md:pl-12 mb-8 md:mb-0 text-center md:text-left">
                  <GlassContainer className="rounded-xl p-6 inline-block">
                    <h3 className="text-2xl font-bold mb-4 text-gray-800 dark:text-white">{t('home.step2Title')}</h3>
                    <p className="text-gray-600 dark:text-gray-300">{t('home.step2Desc')}</p>
                  </GlassContainer>
                </div>
                
                <div className="md:w-8 md:h-8 bg-gradient-to-r from-primary-500 to-secondary-500 rounded-full z-10 flex items-center justify-center text-white font-bold relative">
                  <span>2</span>
                  <div className="absolute w-16 h-16 rounded-full border-2 border-primary-500/30 animate-pulse-glow"></div>
                </div>
                
                <div className="md:w-1/2 md:pr-12">
                  <img src="https://images.unsplash.com/photo-1516383740770-fbcc5ccbece0" alt="Provide information" className="rounded-xl shadow-lg max-w-sm mx-auto" />
                </div>
              </div>
              
              {/* Step 3 */}
              <div className="flex flex-col md:flex-row items-center">
                <div className="md:w-1/2 md:pr-12 mb-8 md:mb-0 text-center md:text-right">
                  <GlassContainer className="rounded-xl p-6 inline-block">
                    <h3 className="text-2xl font-bold mb-4 text-gray-800 dark:text-white">{t('home.step3Title')}</h3>
                    <p className="text-gray-600 dark:text-gray-300">{t('home.step3Desc')}</p>
                  </GlassContainer>
                </div>
                
                <div className="md:w-8 md:h-8 bg-gradient-to-r from-primary-500 to-secondary-500 rounded-full z-10 flex items-center justify-center text-white font-bold relative">
                  <span>3</span>
                  <div className="absolute w-16 h-16 rounded-full border-2 border-primary-500/30 animate-pulse-glow"></div>
                </div>
                
                <div className="md:w-1/2 md:pl-12">
                  <img src="https://images.unsplash.com/photo-1499951360447-b19be8fe80f5" alt="AI conversation" className="rounded-xl shadow-lg max-w-sm mx-auto" />
                </div>
              </div>
              
              {/* Step 4 */}
              <div className="flex flex-col md:flex-row-reverse items-center">
                <div className="md:w-1/2 md:pl-12 mb-8 md:mb-0 text-center md:text-left">
                  <GlassContainer className="rounded-xl p-6 inline-block">
                    <h3 className="text-2xl font-bold mb-4 text-gray-800 dark:text-white">{t('home.step4Title')}</h3>
                    <p className="text-gray-600 dark:text-gray-300">{t('home.step4Desc')}</p>
                  </GlassContainer>
                </div>
                
                <div className="md:w-8 md:h-8 bg-gradient-to-r from-primary-500 to-secondary-500 rounded-full z-10 flex items-center justify-center text-white font-bold relative">
                  <span>4</span>
                  <div className="absolute w-16 h-16 rounded-full border-2 border-primary-500/30 animate-pulse-glow"></div>
                </div>
                
                <div className="md:w-1/2 md:pr-12">
                  <img src="https://images.unsplash.com/photo-1450101499163-c8848c66ca85" alt="Review letter" className="rounded-xl shadow-lg max-w-sm mx-auto" />
                </div>
              </div>
              
              {/* Step 5 */}
              <div className="flex flex-col md:flex-row items-center">
                <div className="md:w-1/2 md:pr-12 mb-8 md:mb-0 text-center md:text-right">
                  <GlassContainer className="rounded-xl p-6 inline-block">
                    <h3 className="text-2xl font-bold mb-4 text-gray-800 dark:text-white">{t('home.step5Title')}</h3>
                    <p className="text-gray-600 dark:text-gray-300">{t('home.step5Desc')}</p>
                  </GlassContainer>
                </div>
                
                <div className="md:w-8 md:h-8 bg-gradient-to-r from-primary-500 to-secondary-500 rounded-full z-10 flex items-center justify-center text-white font-bold relative">
                  <span>5</span>
                  <div className="absolute w-16 h-16 rounded-full border-2 border-primary-500/30 animate-pulse-glow"></div>
                </div>
                
                <div className="md:w-1/2 md:pl-12">
                  <img src="https://images.unsplash.com/photo-1551721434-8b94ddff0e6d" alt="Finalize letter" className="rounded-xl shadow-lg max-w-sm mx-auto" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <AnimatedBackground className="py-20 text-white relative overflow-hidden">
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl md:text-5xl font-bold mb-6 leading-tight">
              Ready to Transform Your Letter Writing Experience?
            </h2>
            <p className="text-xl md:text-2xl text-gray-200 mb-10">
              Join thousands of users who are saving time and sending better letters with our AI-powered assistant.
            </p>
            
            <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-6">
              <Button
                className="w-full sm:w-auto py-6 px-8 rounded-lg bg-white text-primary-600 font-bold hover:shadow-lg hover:shadow-white/20 transition-all text-center text-lg"
                onClick={() => navigate("/auth")}
              >
                {t('common.getStarted')}
              </Button>
              
              <Button
                variant="outline"
                className="w-full sm:w-auto py-6 px-8 rounded-lg glass font-bold border border-white/20 hover:bg-white/10 transition-all text-center text-lg"
                onClick={() => navigate("/letter")}
              >
                {t('common.tryDemoFirst')}
              </Button>
            </div>
            
            <div className="mt-10 pt-10 border-t border-white/10 flex flex-wrap justify-center items-center gap-8">
              <div className="flex flex-col items-center">
                <span className="text-3xl font-bold">5,000+</span>
                <span className="text-gray-300">{t('common.activeUsers')}</span>
              </div>
              <div className="flex flex-col items-center">
                <span className="text-3xl font-bold">50,000+</span>
                <span className="text-gray-300">{t('common.lettersCreated')}</span>
              </div>
              <div className="flex flex-col items-center">
                <span className="text-3xl font-bold">4.9/5</span>
                <span className="text-gray-300">{t('common.averageRating')}</span>
              </div>
            </div>
          </div>
        </div>
      </AnimatedBackground>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-400 py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center mb-4">
                <div className="w-10 h-10 rounded-full bg-gradient-to-r from-primary-600 to-secondary-500 flex items-center justify-center mr-2">
                  <i className="fas fa-robot text-white text-lg"></i>
                </div>
                <span className="text-xl font-bold text-white">{t('common.aiLetterAssistant')}</span>
              </div>
              <p className="mb-4">{t('common.transformingCommunication')}</p>
              <div className="flex space-x-4">
                <a href="#" className="text-gray-400 hover:text-primary-400 transition-colors">
                  <i className="fab fa-twitter"></i>
                </a>
                <a href="#" className="text-gray-400 hover:text-primary-400 transition-colors">
                  <i className="fab fa-facebook"></i>
                </a>
                <a href="#" className="text-gray-400 hover:text-primary-400 transition-colors">
                  <i className="fab fa-instagram"></i>
                </a>
                <a href="#" className="text-gray-400 hover:text-primary-400 transition-colors">
                  <i className="fab fa-linkedin"></i>
                </a>
              </div>
            </div>
            
            <div>
              <h4 className="text-white text-lg font-semibold mb-4">{t('common.quickLinks')}</h4>
              <ul className="space-y-2">
                <li><a href="#features" className="hover:text-primary-400 transition-colors">{t('common.features')}</a></li>
                <li><a href="#how-it-works" className="hover:text-primary-400 transition-colors">{t('common.howItWorks')}</a></li>
                <li><a href="/pricing" className="hover:text-primary-400 transition-colors">{t('common.pricing')}</a></li>
                <li><a href="#" className="hover:text-primary-400 transition-colors">{t('common.faq')}</a></li>
                <li><a href="#" className="hover:text-primary-400 transition-colors">{t('common.support')}</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-white text-lg font-semibold mb-4">{t('common.legal')}</h4>
              <ul className="space-y-2">
                <li><a href="#" className="hover:text-primary-400 transition-colors">{t('common.termsOfService')}</a></li>
                <li><a href="#" className="hover:text-primary-400 transition-colors">{t('common.privacyPolicy')}</a></li>
                <li><a href="#" className="hover:text-primary-400 transition-colors">{t('common.cookiePolicy')}</a></li>
                <li><a href="#" className="hover:text-primary-400 transition-colors">{t('common.dataProcessing')}</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-white text-lg font-semibold mb-4">{t('common.contactUs')}</h4>
              <ul className="space-y-2">
                <li className="flex items-start">
                  <i className="fas fa-envelope mt-1 mr-2 text-primary-500"></i>
                  <span>support@ailetterassistant.com</span>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-phone-alt mt-1 mr-2 text-primary-500"></i>
                  <span>+1 (555) 123-4567</span>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-map-marker-alt mt-1 mr-2 text-primary-500"></i>
                  <span>1234 AI Drive, Tech City, TC 98765</span>
                </li>
              </ul>
            </div>
          </div>
          
          <div className="pt-8 border-t border-gray-800 text-center md:flex md:justify-between md:items-center">
            <p>© {new Date().getFullYear()} {t('common.aiLetterAssistant')}. {t('common.allRightsReserved')}</p>
            <div className="mt-4 md:mt-0 flex justify-center space-x-4">
              <a href="#" className="hover:text-primary-400 transition-colors">{t('common.termsOfService')}</a>
              <a href="#" className="hover:text-primary-400 transition-colors">{t('common.privacyPolicy')}</a>
              <a href="#" className="hover:text-primary-400 transition-colors">{t('common.cookiePolicy')}</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
