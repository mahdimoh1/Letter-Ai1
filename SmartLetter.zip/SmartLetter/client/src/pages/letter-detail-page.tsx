import { NavBar } from "@/components/NavBar";
import { Button } from "@/components/ui/button";
import { AnimatedBackground } from "@/components/AnimatedBackground";
import { GlassContainer } from "@/components/GlassContainer";
import { useTranslation } from "react-i18next";
import { useLetters } from "@/hooks/use-letters";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { formatDate } from "@/lib/utils";
import { ArrowLeft, Download, Copy, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useCallback, useEffect, useState } from "react";

export default function LetterDetailPage({ params }: { params: { id: string } }) {
  const { t } = useTranslation();
  const { user } = useAuth();
  const [_, navigate] = useLocation();
  const { toast } = useToast();
  
  const { letters, isLoadingLetters: isLoading, lettersError: error } = useLetters();
  const [letter, setLetter] = useState<(typeof letters)[0] | null>(null);
  
  // Get the letter by ID
  useEffect(() => {
    if (!isLoading && letters.length > 0) {
      const foundLetter = letters.find(l => l.id === parseInt(params.id));
      setLetter(foundLetter || null);
    }
  }, [letters, params.id, isLoading]);
  
  const handleCopyToClipboard = useCallback(() => {
    if (letter) {
      navigator.clipboard.writeText(letter.content)
        .then(() => {
          toast({
            title: t('letter.copied'),
            description: t('letter.copiedDesc'),
          });
        })
        .catch((error) => {
          console.error('Failed to copy text: ', error);
          toast({
            title: t('letter.copyFailed'),
            description: t('letter.copyFailedDesc'),
            variant: "destructive"
          });
        });
    }
  }, [letter, toast, t]);
  
  const handleDownload = useCallback(() => {
    if (letter) {
      const filename = `letter-${letter.id}.txt`;
      const blob = new Blob([letter.content], { type: 'text/plain' });
      const href = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = href;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  }, [letter]);
  
  return (
    <div className="min-h-screen flex flex-col">
      <NavBar />
      
      <AnimatedBackground
        variant="gradient"
        className="flex-1 pt-32 pb-20"
      >
        <div className="container mx-auto px-4">
          <Button 
            variant="ghost" 
            className="mb-8 text-gray-300" 
            onClick={() => navigate('/my-letters')}
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            {t('letter.backToLetters')}
          </Button>
          
          {isLoading ? (
            <div className="flex justify-center mt-12">
              <Loader2 className="h-8 w-8 animate-spin text-primary-500" />
            </div>
          ) : error ? (
            <GlassContainer className="p-6 rounded-xl text-center">
              <p className="text-red-500">{error.message}</p>
            </GlassContainer>
          ) : !letter ? (
            <GlassContainer className="p-8 rounded-xl text-center max-w-md mx-auto">
              <h3 className="text-xl font-semibold mb-4 text-white">{t('letter.notFound')}</h3>
              <p className="text-gray-300 mb-6">{t('letter.notFoundDesc')}</p>
              <Button 
                onClick={() => navigate("/my-letters")} 
                className="bg-gradient-to-r from-primary-500 to-secondary-500"
              >
                {t('letter.goToMyLetters')}
              </Button>
            </GlassContainer>
          ) : (
            <div className="max-w-4xl mx-auto">
              <div className="flex justify-between items-start mb-6">
                <div>
                  <div className="flex space-x-2 mb-2">
                    <span className="px-2 py-1 text-xs rounded-full bg-primary-500/20 text-primary-300">
                      {letter.type === 'reply' ? t('letter.replyType') : t('letter.newType')}
                    </span>
                    <span className="px-2 py-1 text-xs rounded-full bg-secondary-500/20 text-secondary-300">
                      {letter.language.toUpperCase()}
                    </span>
                    {letter.model && (
                      <span className="px-2 py-1 text-xs rounded-full bg-gray-500/20 text-gray-300">
                        {letter.model.split('/').pop()}
                      </span>
                    )}
                  </div>
                  <h1 className="text-2xl font-bold text-white">
                    {letter.content.split('\n')[0]}
                  </h1>
                  <p className="text-sm text-gray-400 mt-2">
                    {letter.createdAt ? formatDate(new Date(letter.createdAt), "en") : ""}
                  </p>
                </div>
                
                <div className="flex space-x-2">
                  <Button 
                    variant="outline" 
                    className="text-gray-300 border-gray-600 hover:bg-primary-500/20"
                    onClick={handleCopyToClipboard}
                  >
                    <Copy className="mr-2 h-4 w-4" />
                    {t('letter.copy')}
                  </Button>
                  <Button 
                    variant="outline" 
                    className="text-gray-300 border-gray-600 hover:bg-primary-500/20"
                    onClick={handleDownload}
                  >
                    <Download className="mr-2 h-4 w-4" />
                    {t('letter.download')}
                  </Button>
                </div>
              </div>
              
              <GlassContainer className="p-8 rounded-xl">
                <div className="prose prose-lg max-w-none dark:prose-invert">
                  {letter.content.split('\n').map((paragraph, i) => (
                    <p key={i}>{paragraph}</p>
                  ))}
                </div>
              </GlassContainer>
              
              {letter.originalContent && (
                <div className="mt-8">
                  <h3 className="text-xl font-semibold text-white mb-4">
                    {t('letter.originalMessage')}
                  </h3>
                  <GlassContainer className="p-6 rounded-xl bg-gray-900/50">
                    <div className="prose prose-lg max-w-none dark:prose-invert text-gray-400">
                      {letter.originalContent.split('\n').map((paragraph, i) => (
                        <p key={i}>{paragraph}</p>
                      ))}
                    </div>
                  </GlassContainer>
                </div>
              )}
            </div>
          )}
        </div>
      </AnimatedBackground>
    </div>
  );
}
