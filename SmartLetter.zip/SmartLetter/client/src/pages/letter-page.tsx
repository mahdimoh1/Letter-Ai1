import { useState, useEffect } from "react";
import { NavBar } from "@/components/NavBar";
import { Button } from "@/components/ui/button";
import { LetterTypeSelector } from "@/components/letter/LetterTypeSelector";
import { LanguageSelector } from "@/components/letter/LanguageSelector";
import { ModelSelector } from "@/components/letter/ModelSelector";
import { LetterChat, Message } from "@/components/letter/LetterChat";
import { LetterResult } from "@/components/letter/LetterResult";
import { GlassContainer } from "@/components/GlassContainer";
import { AnimatedBackground } from "@/components/AnimatedBackground";
import { useLetters } from "@/hooks/use-letters";
import { useAuth } from "@/hooks/use-auth";
import { useTranslation } from "react-i18next";
import { useToast } from "@/hooks/use-toast";
import { Loader2, AlertTriangle } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

// Step type for letter creation flow
type Step = "input" | "analyzing" | "finalizing";

export default function LetterPage() {
  const { t } = useTranslation();
  const { toast } = useToast();
  const { user } = useAuth();
  const { 
    createLetterMutation, 
    analyzeLetterMutation, 
    generateLetterMutation 
  } = useLetters();
  
  // Letter creation state
  const [step, setStep] = useState<Step>("input");
  const [letterType, setLetterType] = useState("reply");
  const [language, setLanguage] = useState("en");
  const [model, setModel] = useState("gemini-1.5-pro");
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "assistant" as const,
      content: letterType === "reply" 
        ? "Please paste the letter you received, and I'll help you craft a response." 
        : "Tell me what you'd like to write about, and I'll help you create a new letter."
    }
  ]);
  const [generatedContent, setGeneratedContent] = useState("");
  
  // Check if user has reached the free tier limit
  const hasReachedLimit = !user?.isPremium && (user?.monthlyLetterCount ?? 0) >= 3;
  
  // Reset messages when letter type changes
  useEffect(() => {
    setMessages([
      {
        role: "assistant" as const,
        content: letterType === "reply" 
          ? "Please paste the letter you received, and I'll help you craft a response." 
          : "Tell me what you'd like to write about, and I'll help you create a new letter."
      }
    ]);
    setStep("input");
    setGeneratedContent("");
  }, [letterType]);
  
  // Handle user message submission
  const handleSendMessage = (content: string) => {
    if (hasReachedLimit) {
      toast({
        title: "Monthly limit reached",
        description: t('letter.limitReached'),
        variant: "destructive"
      });
      return;
    }
    
    // Add user message to chat
    const updatedMessages: Message[] = [
      ...messages,
      { role: "user", content }
    ];
    setMessages(updatedMessages);
    
    // Either analyze the letter or generate a response based on the current step
    if (step === "input") {
      // First message, analyze the letter
      analyzeLetterMutation.mutate({
        content,
        type: letterType,
        language,
        model,
        history: []
      }, {
        onSuccess: (data) => {
          setMessages([
            ...updatedMessages,
            { role: "assistant" as const, content: data.response }
          ]);
          setStep("analyzing");
        }
      });
    } else if (step === "analyzing") {
      // Follow-up message, generate the letter
      generateLetterMutation.mutate({
        content,
        type: letterType,
        language,
        model,
        history: updatedMessages
      }, {
        onSuccess: (data) => {
          setGeneratedContent(data.response);
          setStep("finalizing");
          
          // Add success message to chat
          setMessages([
            ...updatedMessages,
            { 
              role: "assistant" as const, 
              content: "I've prepared your letter. You can review it, request edits, or finalize it if you're satisfied." 
            }
          ]);
        }
      });
    }
  };
  
  // Handle letter finalization
  const handleFinalizeLetter = (content: string) => {
    createLetterMutation.mutate({
      content,
      originalContent: messages[1]?.content || "",
      type: letterType,
      language,
      model
    }, {
      onSuccess: () => {
        // Reset the form for a new letter
        setStep("input");
        setMessages([
          {
            role: "assistant" as const,
            content: "Your letter has been saved! Would you like to create another letter?"
          }
        ]);
        setGeneratedContent("");
      }
    });
  };
  
  // Handle request for edits
  const handleRequestEdit = () => {
    setMessages([
      ...messages,
      { 
        role: "assistant" as const, 
        content: "What changes would you like to make to the letter?" 
      }
    ]);
  };
  
  // Loading states
  const isAnalyzing = analyzeLetterMutation.isPending;
  const isGenerating = generateLetterMutation.isPending;
  const isSaving = createLetterMutation.isPending;
  
  return (
    <div className="min-h-screen flex flex-col">
      <NavBar />
      
      <AnimatedBackground
        variant="gradient"
        className="flex-1 pt-32 pb-20"
      >
        <div className="container mx-auto px-4">
          <h1 className="text-3xl font-bold text-white mb-8 text-center">
            AI Letter Assistant
          </h1>
          
          {hasReachedLimit && (
            <Alert className="mb-8 border-yellow-500 bg-yellow-500/20 text-white max-w-3xl mx-auto">
              <AlertTriangle className="h-5 w-5" />
              <AlertTitle>Monthly Limit Reached</AlertTitle>
              <AlertDescription>
                {t('letter.limitReached')}
              </AlertDescription>
            </Alert>
          )}
          
          <div className="flex flex-col lg:flex-row gap-6 max-w-6xl mx-auto">
            {/* Letter Configuration Panel */}
            {step === "input" && (
              <div className="lg:w-1/3 space-y-6">
                <GlassContainer
                  variant="dark"
                  className="rounded-xl p-6"
                >
                  <LetterTypeSelector 
                    selectedType={letterType}
                    onChange={setLetterType}
                  />
                  
                  <LanguageSelector
                    selectedLanguage={language}
                    onChange={setLanguage}
                  />
                  
                  <ModelSelector
                    selectedModel={model}
                    onChange={setModel}
                    isPremium={!!user?.isPremium}
                    disabled={hasReachedLimit}
                  />
                </GlassContainer>
              </div>
            )}
            
            {/* Chat Interface */}
            <div className={step === "input" ? "lg:w-2/3" : "w-full"}>
              {step === "finalizing" ? (
                <LetterResult
                  content={generatedContent}
                  onEdit={handleRequestEdit}
                  onFinalize={handleFinalizeLetter}
                />
              ) : (
                <LetterChat
                  messages={messages}
                  onSendMessage={handleSendMessage}
                  placeholderText={
                    letterType === "reply" 
                      ? t('letter.pasteLetterPlaceholder')
                      : t('letter.letterPlaceholder')
                  }
                  isLoading={isAnalyzing || isGenerating}
                />
              )}
            </div>
          </div>
          
          {/* Loading indicators */}
          {(isAnalyzing || isGenerating || isSaving) && (
            <div className="flex justify-center mt-8">
              <div className="flex items-center space-x-2 text-white bg-primary-500/20 py-2 px-4 rounded-full">
                <Loader2 className="h-5 w-5 animate-spin" />
                <span>
                  {isAnalyzing ? t('letter.processing') : 
                   isGenerating ? "Generating your letter..." : 
                   "Saving your letter..."}
                </span>
              </div>
            </div>
          )}
        </div>
      </AnimatedBackground>
    </div>
  );
}
