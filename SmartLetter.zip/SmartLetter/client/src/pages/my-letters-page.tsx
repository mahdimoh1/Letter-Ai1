import { NavBar } from "@/components/NavBar";
import { Button } from "@/components/ui/button";
import { AnimatedBackground } from "@/components/AnimatedBackground";
import { GlassContainer } from "@/components/GlassContainer";
import { useTranslation } from "react-i18next";
import { useLetters } from "@/hooks/use-letters";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { formatDate } from "@/lib/utils";
import { Share, Download, ArrowLeft, Loader2 } from "lucide-react";
import { useIsMobile } from "@/hooks/use-mobile";
import { truncateText } from "@/lib/utils";

export default function MyLettersPage() {
  const { t } = useTranslation();
  const { user } = useAuth();
  const [_, navigate] = useLocation();
  const isMobile = useIsMobile();
  
  const { letters, isLoadingLetters: isLoading, lettersError: error } = useLetters();
  
  return (
    <div className="min-h-screen flex flex-col">
      <NavBar />
      
      <AnimatedBackground
        variant="gradient"
        className="flex-1 pt-32 pb-20"
      >
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-8">
            <h1 className="text-3xl font-bold text-white">
              {t('my.letters')}
            </h1>
            <Button 
              onClick={() => navigate("/letter")} 
              className="bg-gradient-to-r from-primary-500 to-secondary-500"
            >
              <PenTool className="mr-2 h-4 w-4" />
              {t('my.newLetter')}
            </Button>
          </div>
          
          {isLoading ? (
            <div className="flex justify-center mt-12">
              <Loader2 className="h-8 w-8 animate-spin text-primary-500" />
            </div>
          ) : error ? (
            <GlassContainer className="p-6 rounded-xl text-center">
              <p className="text-red-500">{error.message}</p>
            </GlassContainer>
          ) : letters.length === 0 ? (
            <GlassContainer className="p-8 rounded-xl text-center max-w-md mx-auto">
              <h3 className="text-xl font-semibold mb-4 text-white">{t('my.noLetters')}</h3>
              <p className="text-gray-300 mb-6">{t('my.noLettersDesc')}</p>
              <Button 
                onClick={() => navigate("/letter")} 
                className="bg-gradient-to-r from-primary-500 to-secondary-500"
              >
                {t('my.createFirstLetter')}
              </Button>
            </GlassContainer>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {letters.map((letter) => (
                <GlassContainer 
                  key={letter.id} 
                  className="p-6 rounded-xl hover:shadow-lg transition-all duration-300"
                >
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <span className="text-xs uppercase tracking-wider text-gray-400">
                        {letter.type === 'reply' ? t('letter.replyType') : t('letter.newType')}
                      </span>
                      <h3 className="text-lg font-semibold text-white mt-1">
                        {truncateText(letter.content.split('\n')[0] || t('letter.untitled'), 60)}
                      </h3>
                    </div>
                    <div className="flex space-x-2">
                      <span className="px-2 py-1 text-xs rounded-full bg-primary-500/20 text-primary-300">
                        {letter.language.toUpperCase()}
                      </span>
                      {letter.model && (
                        <span className="px-2 py-1 text-xs rounded-full bg-secondary-500/20 text-secondary-300">
                          {letter.model.split('/').pop()}
                        </span>
                      )}
                    </div>
                  </div>
                  
                  <div className="mb-4">
                    <p className="text-gray-300 line-clamp-3">
                      {truncateText(letter.content, 200)}
                    </p>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <div className="text-xs text-gray-400">
                      {letter.createdAt ? formatDate(new Date(letter.createdAt), "en") : ""}
                    </div>
                    
                    <div className="flex space-x-2">
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="text-gray-300 border-gray-600 hover:bg-primary-500/20"
                        onClick={() => {
                          // View letter implementation
                          // For now, just show the full content
                          navigate(`/letter/${letter.id}`);
                        }}
                      >
                        {t('my.viewLetter')}
                      </Button>
                    </div>
                  </div>
                </GlassContainer>
              ))}
            </div>
          )}
        </div>
      </AnimatedBackground>
    </div>
  );
}

import { PenTool } from "lucide-react";
