import { NavBar } from "@/components/NavBar";
import { Button } from "@/components/ui/button";
import { GlassContainer } from "@/components/GlassContainer";
import { AnimatedBackground } from "@/components/AnimatedBackground";
import { useTranslation } from "react-i18next";
import { getGradientClass } from "@/lib/utils";
import { useAuth } from "@/hooks/use-auth";
import { Badge } from "@/components/ui/badge";
import { Check, X, ArrowRight, Loader2 } from "lucide-react";
import { useLocation } from "wouter";

export default function PricingPage() {
  const { t } = useTranslation();
  const { user, updatePremiumStatusMutation } = useAuth();
  const [_, navigate] = useLocation();
  
  const gradientTextClass = getGradientClass();
  
  const handleSubscribe = () => {
    if (!user) {
      navigate("/auth");
      return;
    }
    
    // For demo, we'll just toggle the premium status
    updatePremiumStatusMutation.mutate({ isPremium: true });
  };
  
  const handleDowngrade = () => {
    updatePremiumStatusMutation.mutate({ isPremium: false });
  };
  
  return (
    <div className="min-h-screen flex flex-col">
      <NavBar />
      
      <AnimatedBackground className="flex-1 pt-32 pb-20">
        <div className="container mx-auto px-4 relative z-10">
          <div className="text-center mb-16">
            <h2 className={`text-3xl md:text-4xl font-bold mb-4 ${gradientTextClass} inline-block`}>
              {t('pricing.simple')}
            </h2>
            <p className="text-lg text-gray-600 dark:text-gray-400 max-w-3xl mx-auto">
              {t('pricing.pricingSubtitle')}
            </p>
          </div>
          
          <div className="flex flex-col lg:flex-row gap-8 max-w-5xl mx-auto">
            {/* Free Plan */}
            <div className="lg:w-1/2">
              <GlassContainer 
                className="rounded-2xl overflow-hidden h-full"
              >
                <div className="p-8">
                  <h3 className="text-2xl font-bold text-gray-800 dark:text-white mb-2">
                    {t('pricing.freePlan')}
                  </h3>
                  <p className="text-gray-600 dark:text-gray-300 mb-6">
                    {t('pricing.freePlanDesc')}
                  </p>
                  
                  <div className="flex items-baseline mb-8">
                    <span className="text-4xl font-bold text-gray-800 dark:text-white">$0</span>
                    <span className="text-gray-500 dark:text-gray-400 ml-2">/month</span>
                  </div>
                  
                  <ul className="space-y-3 mb-8">
                    <li className="flex items-center text-gray-600 dark:text-gray-300">
                      <Check className="text-green-500 mr-3 h-5 w-5" />
                      <span>{t('pricing.threeLetters')}</span>
                    </li>
                    <li className="flex items-center text-gray-600 dark:text-gray-300">
                      <Check className="text-green-500 mr-3 h-5 w-5" />
                      <span>{t('pricing.standardAI')}</span>
                    </li>
                    <li className="flex items-center text-gray-600 dark:text-gray-300">
                      <Check className="text-green-500 mr-3 h-5 w-5" />
                      <span>{t('pricing.basicEditing')}</span>
                    </li>
                    <li className="flex items-center text-gray-600 dark:text-gray-300">
                      <Check className="text-green-500 mr-3 h-5 w-5" />
                      <span>{t('pricing.languageSupport')}</span>
                    </li>
                    <li className="flex items-center text-gray-400 line-through">
                      <X className="text-gray-400 mr-3 h-5 w-5" />
                      <span>{t('pricing.advancedAI')}</span>
                    </li>
                    <li className="flex items-center text-gray-400 line-through">
                      <X className="text-gray-400 mr-3 h-5 w-5" />
                      <span>{t('pricing.priorityProcessing')}</span>
                    </li>
                  </ul>
                  
                  {user && !user.isPremium ? (
                    <Button
                      className="w-full py-3 px-6 rounded-lg glass text-primary-600 dark:text-primary-400 font-medium hover:bg-white/10 dark:hover:bg-white/5 transition-all"
                      onClick={() => navigate("/letter")}
                    >
                      {t('pricing.startFree')}
                    </Button>
                  ) : user && user.isPremium ? (
                    <Button
                      className="w-full py-3 px-6 rounded-lg glass text-primary-600 dark:text-primary-400 font-medium hover:bg-white/10 dark:hover:bg-white/5 transition-all"
                      onClick={handleDowngrade}
                      disabled={updatePremiumStatusMutation.isPending}
                    >
                      {updatePremiumStatusMutation.isPending ? (
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      ) : null}
                      Downgrade to Free
                    </Button>
                  ) : (
                    <Button
                      className="w-full py-3 px-6 rounded-lg glass text-primary-600 dark:text-primary-400 font-medium hover:bg-white/10 dark:hover:bg-white/5 transition-all"
                      onClick={() => navigate("/auth")}
                    >
                      {t('pricing.startFree')}
                    </Button>
                  )}
                </div>
              </GlassContainer>
            </div>
            
            {/* Premium Plan */}
            <div className="lg:w-1/2 rounded-2xl overflow-hidden relative">
              <div className="absolute inset-0 bg-gradient-to-br from-primary-600 to-secondary-600 opacity-95"></div>
              <div className="absolute -top-6 -right-6 w-24 h-24 rounded-full bg-yellow-300 opacity-20 blur-xl"></div>
              <div className="absolute -bottom-8 -left-8 w-28 h-28 rounded-full bg-primary-300 opacity-20 blur-xl"></div>
              
              <div className="p-8 relative z-10">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-2xl font-bold text-white mb-2">
                      {t('pricing.premiumPlan')}
                    </h3>
                    <p className="text-primary-100 mb-6">
                      {t('pricing.premiumPlanDesc')}
                    </p>
                  </div>
                  <Badge variant="popular" className="uppercase">
                    {t('pricing.popular')}
                  </Badge>
                </div>
                
                <div className="flex items-baseline mb-8">
                  <span className="text-4xl font-bold text-white">$12</span>
                  <span className="text-primary-200 ml-2">/month</span>
                </div>
                
                <ul className="space-y-3 mb-8">
                  <li className="flex items-center text-white">
                    <Check className="text-green-300 mr-3 h-5 w-5" />
                    <span>{t('pricing.unlimited')}</span>
                  </li>
                  <li className="flex items-center text-white">
                    <Check className="text-green-300 mr-3 h-5 w-5" />
                    <span>{t('pricing.allModels')}</span>
                  </li>
                  <li className="flex items-center text-white">
                    <Check className="text-green-300 mr-3 h-5 w-5" />
                    <span>{t('pricing.advancedEditing')}</span>
                  </li>
                  <li className="flex items-center text-white">
                    <Check className="text-green-300 mr-3 h-5 w-5" />
                    <span>{t('pricing.priorityProcessing')}</span>
                  </li>
                  <li className="flex items-center text-white">
                    <Check className="text-green-300 mr-3 h-5 w-5" />
                    <span>{t('pricing.templates')}</span>
                  </li>
                  <li className="flex items-center text-white">
                    <Check className="text-green-300 mr-3 h-5 w-5" />
                    <span>{t('pricing.saveOrganize')}</span>
                  </li>
                </ul>
                
                {user && user.isPremium ? (
                  <Button
                    className="w-full py-3 px-6 rounded-lg bg-white text-primary-600 font-medium hover:shadow-lg transition-all"
                    onClick={() => navigate("/letter")}
                  >
                    Continue to Letters
                  </Button>
                ) : (
                  <Button
                    className="w-full py-3 px-6 rounded-lg bg-white text-primary-600 font-medium hover:shadow-lg transition-all"
                    onClick={handleSubscribe}
                    disabled={updatePremiumStatusMutation.isPending}
                  >
                    {updatePremiumStatusMutation.isPending ? (
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    ) : null}
                    {t('pricing.upgradeNow')}
                  </Button>
                )}
              </div>
            </div>
          </div>
          
          <div className="mt-12 text-center">
            <p className="text-gray-300">{t('pricing.customPlan')}</p>
            <a href="#" className="text-primary-400 font-medium hover:underline inline-flex items-center">
              {t('pricing.contactUs')}
              <ArrowRight className="ml-2 h-4 w-4" />
            </a>
          </div>
        </div>
      </AnimatedBackground>
    </div>
  );
}
