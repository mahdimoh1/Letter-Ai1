import { Prompt } from "@shared/schema";

interface GeminiContent {
  role: string;
  parts: { text: string }[];
}

interface GeminiRequest {
  contents: GeminiContent[];
  generationConfig?: {
    maxOutputTokens?: number;
    temperature?: number;
  };
}

interface GeminiResponse {
  candidates: {
    content: {
      parts: { text: string }[];
    };
    finishReason: string;
  }[];
}

export async function generateWithGemini(
  prompt: Prompt,
  content: string,
  history: { role: "user" | "model" | "assistant"; content: string }[] = [],
  model: string = "gemini-1.0-pro"
): Promise<string> {
  const apiKey = process.env.GEMINI_API_KEY;
  
  if (!apiKey) {
    throw new Error("GEMINI_API_KEY environment variable is not set");
  }
  
  // Convert any assistant roles to model roles for Gemini API compatibility
  const formattedHistory = history.map(msg => ({
    role: msg.role === "assistant" ? "model" : msg.role,
    parts: [{ text: msg.content }]
  }));
  
  // Format the prompt and message history for Gemini
  let contents: GeminiContent[];
  
  // If history is empty, just send a simple request with the prompt and content
  if (history.length === 0) {
    contents = [
      { role: "user", parts: [{ text: `${prompt.content}\n\n${content}` }] }
    ];
  } else {
    // Otherwise, include the prompt with the history
    contents = [
      { role: "user", parts: [{ text: prompt.content }] },
      ...formattedHistory,
      { role: "user", parts: [{ text: content }] }
    ];
  }
  
  const requestBody: GeminiRequest = {
    contents,
    generationConfig: {
      maxOutputTokens: 2000,
      temperature: 0.7
    }
  };
  
  try {
    // Convert model IDs to the format expected by the Gemini API
    // First, strip any provider prefix (e.g., "openai/") if present
    let modelId = model.includes('/') ? model.split('/')[1] : model;
    
    // Map our internal model IDs to the Gemini API model names
    if (modelId === "gemini-1.5-pro") {
      modelId = "models/gemini-1.5-pro";
    } else if (modelId === "gemini-pro-vision") {
      modelId = "models/gemini-pro-vision";
    } else {
      // Default to gemini-1.5-pro if model not recognized
      modelId = "models/gemini-1.5-pro";
    }
    
    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/${modelId}:generateContent?key=${apiKey}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(requestBody)
    });
    
    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Gemini API error (${response.status}): ${errorText}`);
    }
    
    const data = await response.json() as GeminiResponse;
    return data.candidates[0].content.parts[0].text;
  } catch (error) {
    console.error("Gemini API error:", error);
    throw error;
  }
}
