import { generateWithOpenRouter } from "./openrouter";
import { generateWithOpenAI } from "./openai";
import { generateWithGemini } from "./gemini";
import { storage } from "../storage";
import { Prompt } from "@shared/schema";

interface ChatMessage {
  role: "user" | "assistant" | "model";
  content: string;
}

export async function generateLetter(
  letterType: string,
  language: string,
  model: string,
  content: string,
  history: ChatMessage[] = []
): Promise<string> {
  try {
    // Get the appropriate prompt
    const prompts = await storage.getPromptsByType(letterType, language);
    
    // Use default prompt if none found
    if (prompts.length === 0) {
      throw new Error(`No prompt found for type "${letterType}" and language "${language}"`);
    }
    
    // Use the default prompt if available, otherwise use the first one
    const prompt = prompts.find(p => p.isDefault) || prompts[0];
    
    // Use Gemini by default or if specified
    if (model.includes("gemini")) {
      // Pass the history directly to Gemini, conversion happens in the Gemini module
      return generateWithGemini(prompt, content, history, model);
    }
    
    // Default to OpenAI
    return generateWithOpenAI(prompt, content, history);
  } catch (error) {
    console.error("Error generating letter:", error);
    throw error;
  }
}

export async function analyzeAndRespond(
  letterType: string,
  language: string,
  model: string,
  content: string,
  history: ChatMessage[] = []
): Promise<string> {
  // Same as generateLetter for now, but could have different logic in the future
  return generateLetter(letterType, language, model, content, history);
}
