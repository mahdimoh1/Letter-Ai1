import { Prompt } from "@shared/schema";

interface OpenAIMessage {
  role: "user" | "assistant" | "system";
  content: string;
}

interface OpenAIRequest {
  model: string;
  messages: OpenAIMessage[];
  max_tokens?: number;
  temperature?: number;
}

interface OpenAIResponse {
  choices: {
    message: {
      content: string;
    };
    finish_reason: string;
  }[];
  id: string;
  model: string;
  usage: {
    prompt_tokens: number;
    completion_tokens: number;
    total_tokens: number;
  };
}

export async function generateWithOpenAI(
  prompt: Prompt,
  content: string,
  history: { role: "user" | "assistant" | "model"; content: string }[] = []
): Promise<string> {
  const apiKey = process.env.OPENAI_API_KEY;
  
  if (!apiKey) {
    throw new Error("OPENAI_API_KEY environment variable is not set");
  }
  
  // Convert any 'model' roles to 'assistant' for OpenAI API compatibility
  const messages: OpenAIMessage[] = [
    { role: "system", content: prompt.content },
    ...history.map(msg => ({
      role: msg.role === "model" ? "assistant" : msg.role,
      content: msg.content
    })),
    { role: "user", content }
  ];
  
  const requestBody: OpenAIRequest = {
    model: "gpt-3.5-turbo",
    messages,
    max_tokens: 2000,
    temperature: 0.7
  };
  
  try {
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${apiKey}`
      },
      body: JSON.stringify(requestBody)
    });
    
    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`OpenAI API error (${response.status}): ${errorText}`);
    }
    
    const data = await response.json() as OpenAIResponse;
    return data.choices[0].message.content;
  } catch (error) {
    console.error("OpenAI API error:", error);
    throw error;
  }
}
