import { Express } from "express";
import { storage } from "./storage";
import { analyzeAndRespond, generateLetter } from "./ai";
import { insertLetterSchema, insertPromptSchema } from "@shared/schema";

export function setupAPI(app: Express) {
  // Letters related endpoints
  app.post("/api/letters/analyze", async (req, res, next) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      const { content, type, language, model, history } = req.body;
      
      // Check if user is allowed to create a new letter
      if (!req.user.isPremium && req.user.monthlyLetterCount >= 3) {
        return res.status(403).json({ message: "Monthly letter limit reached. Upgrade to premium for unlimited letters." });
      }
      
      const response = await analyzeAndRespond(type, language, model, content, history);
      res.json({ response });
    } catch (error) {
      next(error);
    }
  });
  
  app.post("/api/letters/generate", async (req, res, next) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      const { content, type, language, model, history } = req.body;
      
      // Check if user is allowed to create a new letter
      if (!req.user.isPremium && req.user.monthlyLetterCount >= 3) {
        return res.status(403).json({ message: "Monthly letter limit reached. Upgrade to premium for unlimited letters." });
      }
      
      const response = await generateLetter(type, language, model, content, history);
      res.json({ response });
    } catch (error) {
      next(error);
    }
  });
  
  app.post("/api/letters", async (req, res, next) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      // Validate request body against the schema
      const letterData = insertLetterSchema.parse(req.body);
      
      // Check if user is allowed to create a new letter
      if (!req.user.isPremium && req.user.monthlyLetterCount >= 3) {
        return res.status(403).json({ message: "Monthly letter limit reached. Upgrade to premium for unlimited letters." });
      }
      
      // Create letter
      const letter = await storage.createLetter(req.user.id, letterData);
      
      // Increment user's letter count
      await storage.incrementLetterCount(req.user.id);
      
      res.status(201).json(letter);
    } catch (error) {
      next(error);
    }
  });
  
  app.get("/api/letters", async (req, res, next) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      const letters = await storage.getLettersByUserId(req.user.id);
      res.json(letters);
    } catch (error) {
      next(error);
    }
  });
  
  app.get("/api/letters/:id", async (req, res, next) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      const letterId = parseInt(req.params.id);
      if (isNaN(letterId)) {
        return res.status(400).json({ message: "Invalid letter ID" });
      }
      
      const letter = await storage.getLetter(letterId);
      
      if (!letter) {
        return res.status(404).json({ message: "Letter not found" });
      }
      
      // Check if user owns this letter
      if (letter.userId !== req.user.id) {
        return res.status(403).json({ message: "You don't have permission to access this letter" });
      }
      
      res.json(letter);
    } catch (error) {
      next(error);
    }
  });
  
  // Admin API for prompt management
  app.get("/api/prompts", async (req, res, next) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    // In a real app, check if user is admin
    // For this MVP, we'll allow any authenticated user to manage prompts
    
    try {
      const prompts = await storage.getPrompts();
      res.json(prompts);
    } catch (error) {
      next(error);
    }
  });
  
  app.post("/api/prompts", async (req, res, next) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      // Validate request body against the schema
      const promptData = insertPromptSchema.parse(req.body);
      
      // Create prompt
      const prompt = await storage.createPrompt(promptData);
      res.status(201).json(prompt);
    } catch (error) {
      next(error);
    }
  });
  
  app.put("/api/prompts/:id", async (req, res, next) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      const promptId = parseInt(req.params.id);
      if (isNaN(promptId)) {
        return res.status(400).json({ message: "Invalid prompt ID" });
      }
      
      // Validate request body against the schema
      const promptData = insertPromptSchema.partial().parse(req.body);
      
      // Update prompt
      const prompt = await storage.updatePrompt(promptId, promptData);
      
      if (!prompt) {
        return res.status(404).json({ message: "Prompt not found" });
      }
      
      res.json(prompt);
    } catch (error) {
      next(error);
    }
  });
  
  app.delete("/api/prompts/:id", async (req, res, next) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      const promptId = parseInt(req.params.id);
      if (isNaN(promptId)) {
        return res.status(400).json({ message: "Invalid prompt ID" });
      }
      
      const success = await storage.deletePrompt(promptId);
      
      if (!success) {
        return res.status(404).json({ message: "Prompt not found" });
      }
      
      res.status(204).end();
    } catch (error) {
      next(error);
    }
  });
}
