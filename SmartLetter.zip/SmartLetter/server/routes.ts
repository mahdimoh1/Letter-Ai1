import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { setupAPI } from "./api";

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication routes
  setupAuth(app);
  
  // Setup API routes
  setupAPI(app);
  
  // Create HTTP server
  const httpServer = createServer(app);

  return httpServer;
}
