import { users, type User, type InsertUser, letters, type Letter, type InsertLetter, prompts, type Prompt, type InsertPrompt, defaultPrompts } from "@shared/schema";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { db, pool } from "./db";
import { eq, and, desc } from "drizzle-orm";

const PostgresSessionStore = connectPg(session);

// Storage interface with all the methods we need
export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserPremiumStatus(id: number, isPremium: boolean): Promise<User | undefined>;
  resetMonthlyLetterCount(id: number): Promise<User | undefined>;
  incrementLetterCount(id: number): Promise<User | undefined>;
  
  // Letter methods
  createLetter(userId: number, letter: InsertLetter): Promise<Letter>;
  getLettersByUserId(userId: number): Promise<Letter[]>;
  getLetter(id: number): Promise<Letter | undefined>;
  
  // Prompt methods
  getPrompts(): Promise<Prompt[]>;
  getPromptsByType(type: string, language: string): Promise<Prompt[]>;
  createPrompt(prompt: InsertPrompt): Promise<Prompt>;
  updatePrompt(id: number, prompt: Partial<InsertPrompt>): Promise<Prompt | undefined>;
  deletePrompt(id: number): Promise<boolean>;
  
  // Session store
  sessionStore: any; // Using any for session store type for simplicity
}

export class DatabaseStorage implements IStorage {
  sessionStore: any; // Using any for session store type for simplicity

  constructor() {
    this.sessionStore = new PostgresSessionStore({
      pool,
      createTableIfMissing: true
    });
    
    // Initialize default prompts
    this.initializeDefaultPrompts();
  }

  private async initializeDefaultPrompts() {
    // Check if any prompts exist
    const existingPrompts = await db.select().from(prompts);
    
    // Only add default prompts if none exist
    if (existingPrompts.length === 0) {
      for (const prompt of defaultPrompts) {
        await this.createPrompt(prompt);
      }
    }
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async updateUserPremiumStatus(id: number, isPremium: boolean): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set({ isPremium })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  async resetMonthlyLetterCount(id: number): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set({ 
        monthlyLetterCount: 0,
        lastReset: new Date() 
      })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  async incrementLetterCount(id: number): Promise<User | undefined> {
    // First get the current user to get the current count
    const user = await this.getUser(id);
    if (!user) return undefined;
    
    // Then update with incremented count
    const [updatedUser] = await db
      .update(users)
      .set({ 
        monthlyLetterCount: user.monthlyLetterCount + 1 
      })
      .where(eq(users.id, id))
      .returning();
    return updatedUser;
  }

  // Letter methods
  async createLetter(userId: number, letter: InsertLetter): Promise<Letter> {
    const [newLetter] = await db
      .insert(letters)
      .values({
        ...letter,
        userId
      })
      .returning();
    return newLetter;
  }

  async getLettersByUserId(userId: number): Promise<Letter[]> {
    return await db
      .select()
      .from(letters)
      .where(eq(letters.userId, userId))
      .orderBy(desc(letters.id)); // Using id in descending order to show newest first
  }

  async getLetter(id: number): Promise<Letter | undefined> {
    const [letter] = await db
      .select()
      .from(letters)
      .where(eq(letters.id, id));
    return letter;
  }

  // Prompt methods
  async getPrompts(): Promise<Prompt[]> {
    return await db.select().from(prompts);
  }

  async getPromptsByType(type: string, language: string): Promise<Prompt[]> {
    return await db
      .select()
      .from(prompts)
      .where(
        and(
          eq(prompts.type, type),
          eq(prompts.language, language)
        )
      );
  }

  async createPrompt(prompt: InsertPrompt): Promise<Prompt> {
    const [newPrompt] = await db
      .insert(prompts)
      .values(prompt)
      .returning();
    return newPrompt;
  }

  async updatePrompt(id: number, prompt: Partial<InsertPrompt>): Promise<Prompt | undefined> {
    const [updatedPrompt] = await db
      .update(prompts)
      .set(prompt)
      .where(eq(prompts.id, id))
      .returning();
    return updatedPrompt;
  }

  async deletePrompt(id: number): Promise<boolean> {
    const result = await db
      .delete(prompts)
      .where(eq(prompts.id, id));
    return true; // If we get here, the delete was successful
  }
}

export const storage = new DatabaseStorage();
