import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  isPremium: boolean("is_premium").default(false).notNull(),
  monthlyLetterCount: integer("monthly_letter_count").default(0).notNull(),
  lastReset: timestamp("last_reset").defaultNow(),
});

export const letters = pgTable("letters", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  content: text("content").notNull(),
  originalContent: text("original_content"),
  type: text("type").notNull(), // 'new' or 'reply'
  language: text("language").notNull(), // 'en' or 'fa'
  model: text("model").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const prompts = pgTable("prompts", {
  id: serial("id").primaryKey(),
  type: text("type").notNull(), // 'new', 'reply', 'analysis', etc.
  content: text("content").notNull(),
  language: text("language").notNull(), // 'en' or 'fa'
  isDefault: boolean("is_default").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertLetterSchema = createInsertSchema(letters).pick({
  content: true,
  originalContent: true,
  type: true,
  language: true,
  model: true,
});

export const insertPromptSchema = createInsertSchema(prompts).pick({
  type: true,
  content: true,
  language: true,
  isDefault: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertLetter = z.infer<typeof insertLetterSchema>;
export type Letter = typeof letters.$inferSelect;

export type InsertPrompt = z.infer<typeof insertPromptSchema>;
export type Prompt = typeof prompts.$inferSelect;

// For AI models
export const aiModels = [
  { id: "gemini-1.5-pro", name: "Gemini 1.5 Pro", provider: "Google" },
  { id: "gemini-pro-vision", name: "Gemini 1.0 Pro Vision", provider: "Google" },
  { id: "openai/gpt-3.5-turbo", name: "GPT-3.5 Turbo", provider: "OpenAI" }
];

// For letter types
export const letterTypes = [
  { id: "new", name: "New Letter" },
  { id: "reply", name: "Reply to Letter" }
];

// For languages
export const languages = [
  { id: "en", name: "English" },
  { id: "fa", name: "Persian" }
];

// Default prompts in English and Persian
export const defaultPrompts = [
  {
    type: "new",
    language: "en",
    content: "You are an AI letter writing assistant. The user wants to write a new letter. Help them by analyzing what they want to say and asking clarifying questions. Once you understand what they need, draft a concise, well-written letter that captures their intent.",
    isDefault: true
  },
  {
    type: "reply",
    language: "en",
    content: "You are an AI letter writing assistant. The user wants to reply to a letter they received. First, analyze the letter content provided by the user. Then, ask clarifying questions about how they want to respond. Finally, draft a concise, appropriate reply that addresses the original letter's content.",
    isDefault: true
  },
  {
    type: "new",
    language: "fa",
    content: "شما یک دستیار هوش مصنوعی برای نوشتن نامه هستید. کاربر می‌خواهد یک نامه جدید بنویسد. با تحلیل آنچه می‌خواهند بگویند و پرسیدن سوالات واضح به آنها کمک کنید. پس از درک آنچه نیاز دارند، یک نامه مختصر و خوب نوشته شده که منظور آنها را منتقل می‌کند، تهیه کنید.",
    isDefault: true
  },
  {
    type: "reply",
    language: "fa",
    content: "شما یک دستیار هوش مصنوعی برای نوشتن نامه هستید. کاربر می‌خواهد به نامه‌ای که دریافت کرده پاسخ دهد. ابتدا، محتوای نامه ارائه شده توسط کاربر را تحلیل کنید. سپس، درباره نحوه پاسخگویی سوالات واضح بپرسید. در نهایت، پاسخی مختصر و مناسب که به محتوای نامه اصلی می‌پردازد، تهیه کنید.",
    isDefault: true
  }
];
